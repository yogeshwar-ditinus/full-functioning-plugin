<?php
/**
 * Plugin Name: Activity Logger
 * Plugin URI: https://yourwebsite.com
 * Description: Logs security alerts, user activities, theme and page changes in CSV file.
 * Version: 3.5
 * Author: Veer Saini
 * Author URI: https://viyog.com
 */

if (!defined('ABSPATH')) exit;

// Constants
define('LOG_FILE', __DIR__ . '/activity_logs.csv');
define('IP_LOG_FILE', __DIR__ . '/ip_access_logs.csv');
define('BLOCKED_IPS_FILE', __DIR__ . '/blocked_ips.csv');
define('CONTACT_FORM_LOG_FILE', __DIR__ . '/contact_form_logs.csv');
define('ADMIN_EMAIL', 'yogeshwarsaini321@gmail.com');
define('OFFICE_IPS', ['192.168.20.8', '192.168.18.113']); // Aapki IP add ki
define('MAX_LOGIN_ATTEMPTS', 5);
define('TIME_WINDOW', 3600);
define('SECURITY_SCAN_INTERVAL', 86400);
date_default_timezone_set('Asia/Kolkata');

// ============ IMPROVED IP DETECTION - LOCAL NETWORK SUPPORT ============
function get_user_ip() {
    // Local/Private IP ko bhi properly detect karega
    $ip_keys = [
        'REMOTE_ADDR',               // Direct connection (sabse accurate for local network)
        'HTTP_CLIENT_IP',            // Client IP
        'HTTP_X_REAL_IP',            // Nginx proxy
        'HTTP_X_FORWARDED_FOR',      // Proxy/Load balancer
        'HTTP_CF_CONNECTING_IP',     // Cloudflare
        'HTTP_X_FORWARDED',          
        'HTTP_X_CLUSTER_CLIENT_IP',  
        'HTTP_FORWARDED_FOR',        
        'HTTP_FORWARDED',            
    ];
    
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) && !empty($_SERVER[$key])) {
            // Multiple IPs ho sakte hain comma-separated
            $ips = explode(',', $_SERVER[$key]);
            
            foreach ($ips as $ip) {
                $ip = trim($ip);
                
                // Validate IP address (both public and private)
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    // Check if Office IP
                    $clean_ip = str_replace(['(Office)', '(Home)'], '', $ip);
                    $clean_ip = trim($clean_ip);
                    
                    if (in_array($clean_ip, OFFICE_IPS) || in_array($ip, OFFICE_IPS)) {
                        return "$clean_ip (Office)";
                    }
                    
                    return "$ip (Home)";
                }
            }
        }
    }
    
    return 'UNKNOWN';
}

// Debug function for IP detection
function get_all_ip_headers() {
    $ip_info = [];
    $headers = [
        'REMOTE_ADDR',
        'HTTP_CLIENT_IP',
        'HTTP_X_REAL_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'SERVER_ADDR',
        'LOCAL_ADDR'
    ];
    
    foreach ($headers as $header) {
        if (isset($_SERVER[$header]) && !empty($_SERVER[$header])) {
            $ip_info[$header] = $_SERVER[$header];
        }
    }
    
    return $ip_info;
}

// Show IP debug info in admin
function log_ip_debug_info() {
    if (current_user_can('manage_options') && isset($_GET['debug_ip'])) {
        echo '<div class="notice notice-info" style="padding: 15px;"><h3>🔍 IP Debug Information:</h3>';
        echo '<p><strong>Detected IP:</strong> <span style="color: green; font-size: 16px;">' . get_user_ip() . '</span></p>';
        echo '<hr><h4>All Available IP Headers:</h4><pre style="background: #f5f5f5; padding: 10px; border-radius: 5px;">';
        
        $all_ips = get_all_ip_headers();
        if (empty($all_ips)) {
            echo "No IP headers found!";
        } else {
            foreach ($all_ips as $header => $value) {
                echo "<strong>$header:</strong> $value\n";
            }
        }
        
        echo '</pre>';
        echo '<p><strong>Office IPs in Config:</strong> ' . implode(', ', OFFICE_IPS) . '</p>';
        echo '</div>';
    }
}
add_action('admin_notices', 'log_ip_debug_info');

function log_activity($user_id, $username, $action) {
    if (!file_exists(LOG_FILE)) {
        $file = fopen(LOG_FILE, 'w');
        fputcsv($file, ['User ID', 'Username', 'Action', 'IP Address', 'Timestamp']);
        fclose($file);
    }
    
    $file = fopen(LOG_FILE, 'a');
    fputcsv($file, [$user_id, $username, $action, get_user_ip(), date('Y-m-d H:i:s')]);
    fclose($file);
}

function send_security_email($alert_name, $username, $action) {
    $subject = "!! Security Alert !! - " . get_bloginfo('name');
    $message = "Alert Type: $alert_name\n";
    $message .= "User: $username\n";
    $message .= "IP Address: " . get_user_ip() . "\n";
    $message .= "Time: " . date('Y-m-d H:i:s') . "\n";
    $message .= "Action: $action\n";
    $message .= "Website: " . get_bloginfo('name') . "\n";
    $message .= "URL: " . get_bloginfo('url');
    
    wp_mail(ADMIN_EMAIL, $subject, $message);
}

function track_activity($action) {
    $user = wp_get_current_user();
    log_activity($user->ID, $user->user_login, $action);
    return [$user->ID, $user->user_login, $action];
}

function track_and_alert($action) {
    $data = track_activity($action);
    send_security_email(trim(explode(':', $action)[0]), $data[1], $action);
}

// Hook setup helper
function add_hooks($hooks) {
    foreach ($hooks as $hook => $callback) {
        $params = isset($callback['params']) ? $callback['params'] : 1;
        add_action($hook, $callback['fn'], 10, $params);
    }
}

// User action hooks
add_hooks([
    'user_register' => [
        'fn' => function($user_id) {
            $user = get_userdata($user_id);
            log_activity($user_id, $user->user_login, 'User Created');
            send_security_email("User Created", $user->user_login, 'User Created');
        }
    ],
    'delete_user' => [
        'fn' => function($user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                log_activity($user_id, $user->user_login, 'User Deleted');
                send_security_email("User Deleted", $user->user_login, 'User Deleted');
            }
        }
    ],
    'wp_login' => [
        'fn' => function($user_login, $user) {
            log_activity($user->ID, $user_login, 'Logged In');
            send_security_email("Successful Login Alert", $user_login, 'Logged In');
            log_ip_access($user_login);
        },
        'params' => 2
    ],
    'clear_auth_cookie' => [
        'fn' => function() {
            $user = wp_get_current_user();
            if ($user->ID) {
                log_activity($user->ID, $user->user_login, 'Logged Out');
                send_security_email("Logout Alert", $user->user_login, 'Logged Out');
            }
        }
    ],
    'wp_login_failed' => [
        'fn' => function($username) {
            log_activity(0, $username, 'Security Alert: Failed Login Attempt');
            send_security_email("Failed Login Attempt", $username, 'Failed Login Attempt');
            log_ip_access($username, 'failed');
        }
    ],
    'set_user_role' => [
        'fn' => function($user_id, $role, $old_roles) {
            $user = get_userdata($user_id);
            if ($user) {
                $action = 'Role Changed: ' . implode(', ', $old_roles) . ' → ' . $role;
                log_activity($user_id, $user->user_login, $action);
                send_security_email("User Role Changed", $user->user_login, $action);
            }
        },
        'params' => 3
    ]
]);

// Content change tracking
function track_page_post_changes($post_ID, $post_after, $post_before) {
    if (wp_is_post_revision($post_ID) || wp_is_post_autosave($post_ID)) return;
    
    $post_type = get_post_type($post_ID);
    $title = $post_after->post_title;
    $action = '';
    
    if ($post_before->post_status === 'auto-draft' && $post_after->post_status === 'publish')
        $action = ucfirst($post_type) . ' Created: ' . $title;
    elseif ($post_before->post_status !== 'trash' && $post_after->post_status === 'trash')
        $action = ucfirst($post_type) . ' Trashed: ' . $title;
    elseif ($post_before->post_status === 'trash' && $post_after->post_status === 'publish')
        $action = ucfirst($post_type) . ' Restored: ' . $title;
    elseif (($post_before->post_content !== $post_after->post_content ||
            $post_before->post_title !== $post_after->post_title ||
            $post_before->post_excerpt !== $post_after->post_excerpt) &&
            $post_before->post_status === 'publish' && $post_after->post_status === 'publish')
        $action = ucfirst($post_type) . ' Modified: ' . $title;
    
    if (!empty($action)) {
        $user = wp_get_current_user();
        log_activity($user->ID, $user->user_login, $action);
    }
}
add_action('post_updated', 'track_page_post_changes', 10, 3);

add_action('before_delete_post', function($post_id) {
    $post = get_post($post_id);
    if ($post && $post->post_status !== 'trash') {
        track_activity(ucfirst($post->post_type) . ' Deleted: ' . $post->post_title);
    }
});

// Theme and plugin changes
add_action('after_switch_theme', function() {
    track_and_alert('Theme Changed to: ' . wp_get_theme()->get('Name'));
});

// IMPROVED PLUGIN TRACKING
add_hooks([
    'upgrader_process_complete' => [
        'fn' => function($upgrader_object, $options) {
            // Plugin Install Detection
            if ($options['type'] == 'plugin' && $options['action'] == 'install') {
                if (isset($upgrader_object->result) && isset($upgrader_object->result['destination_name'])) {
                    $plugin_slug = $upgrader_object->result['destination_name'];
                    track_and_alert('Plugin Installed: ' . $plugin_slug);
                } elseif (!empty($options['plugins'])) {
                    foreach ($options['plugins'] as $plugin) {
                        track_and_alert('Plugin Installed: ' . $plugin);
                    }
                }
            }
            
            // Plugin Update Detection
            if ($options['type'] == 'plugin' && $options['action'] == 'update' && !empty($options['plugins'])) {
                foreach ($options['plugins'] as $plugin) {
                    $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
                    $plugin_name = !empty($plugin_data['Name']) ? $plugin_data['Name'] : $plugin;
                    track_activity('Plugin Updated: ' . $plugin_name);
                }
            }
        },
        'params' => 2
    ],
    'activated_plugin' => [
        'fn' => function($plugin, $network_wide) {
            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
            $plugin_name = !empty($plugin_data['Name']) ? $plugin_data['Name'] : $plugin;
            track_and_alert('Plugin Activated: ' . $plugin_name);
        },
        'params' => 2
    ],
    'deactivated_plugin' => [
        'fn' => function($plugin, $network_wide) {
            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
            $plugin_name = !empty($plugin_data['Name']) ? $plugin_data['Name'] : $plugin;
            track_and_alert('Plugin Deactivated: ' . $plugin_name);
        },
        'params' => 2
    ],
    'deleted_plugin' => [
        'fn' => function($plugin_file, $deleted) {
            if ($deleted) {
                track_and_alert('Plugin Deleted: ' . $plugin_file);
            }
        },
        'params' => 2
    ]
]);

// Options and meta changes
add_hooks([
    'added_option' => ['fn' => function($option) { 
        if (!str_starts_with($option, '_transient')) track_activity("Option Added: $option"); 
    }],
    'updated_option' => ['fn' => function($option) { 
        if (!str_starts_with($option, '_transient')) track_activity("Option Updated: $option"); 
    }],
    'deleted_option' => ['fn' => function($option) { 
        if (!str_starts_with($option, '_transient')) track_activity("Option Deleted: $option"); 
    }],
    'added_post_meta' => [
        'fn' => function($meta_id, $post_id, $meta_key) { 
            if (!str_starts_with($meta_key, '_')) track_activity("Meta Added to Post ID $post_id: $meta_key"); 
        },
        'params' => 3
    ],
    'updated_post_meta' => [
        'fn' => function($meta_id, $post_id, $meta_key) { 
            if (!str_starts_with($meta_key, '_')) track_activity("Meta Updated in Post ID $post_id: $meta_key"); 
        },
        'params' => 3
    ],
    'deleted_post_meta' => [
        'fn' => function($meta_ids, $post_id, $meta_key) { 
            if (!str_starts_with($meta_key, '_')) track_activity("Meta Deleted from Post ID $post_id: $meta_key"); 
        },
        'params' => 3
    ],
    'wp_insert_comment' => [
        'fn' => function($comment_id) { track_activity("New Comment Added: ID $comment_id"); },
        'params' => 1
    ]
]);

// Admin interface
add_action('admin_menu', function() {
    add_menu_page('Activity Logs', 'Activity Logs', 'manage_options', 'activity-logs', 'display_activity_logs', 'dashicons-visibility', 20);
    add_submenu_page('activity-logs', 'Security Monitor', 'Security Monitor', 'manage_options', 'security-monitor', 'display_security_monitor');
    add_submenu_page('activity-logs', 'IP Access Logs', 'IP Access Logs', 'manage_options', 'ip-access-logs', 'display_ip_access_logs');
    add_submenu_page('activity-logs', 'Blocked IPs', 'Blocked IPs', 'manage_options', 'blocked-ips', 'display_blocked_ips');
    add_submenu_page('activity-logs', 'Outdated Plugins', 'Outdated Plugins', 'manage_options', 'outdated-plugins', 'display_outdated_plugins');
    add_submenu_page('activity-logs', 'Contact Form Logs', 'Contact Form Logs', 'manage_options', 'contact-form-logs', 'display_contact_form_logs');
});

function display_activity_logs() {
    $categories = ['All', 'User Created', 'User Deleted', 'Role Changed', 'Logged In', 'Logged Out', 
                  'Security Alert', 'Page Created', 'Page Modified', 'Page Deleted', 'Post Created', 
                  'Post Modified', 'Post Deleted', 'Theme Changed', 'Plugin Installed', 'Plugin Activated', 
                  'Plugin Deactivated', 'Plugin Deleted', 'Plugin Updated'];
    $selected = isset($_GET['log_filter']) ? sanitize_text_field($_GET['log_filter']) : 'All';
    
    echo "<div class='wrap'><h1>Activity Logs</h1>";
    
    // Show current detected IP with prominent display
    $current_ip = get_user_ip();
    $ip_style = strpos($current_ip, 'Office') !== false ? 'color: green;' : 'color: blue;';
    echo "<div class='notice notice-info' style='padding: 15px; background: #f0f8ff;'>";
    echo "<p style='margin: 0; font-size: 14px;'><strong>🌐 Your Current IP:</strong> ";
    echo "<span style='$ip_style font-size: 16px; font-weight: bold;'>$current_ip</span> | ";
    echo "<a href='?page=activity-logs&debug_ip=1' class='button button-small'>🔍 View IP Debug Info</a></p>";
    echo "</div>";
    
    echo "<form method='GET' style='margin: 15px 0;'><input type='hidden' name='page' value='activity-logs'>";
    echo "<select name='log_filter' onchange='this.form.submit()' style='padding: 5px; font-size: 14px;'>";
    
    foreach ($categories as $category) {
        echo "<option value='$category' " . ($selected == $category ? 'selected' : '') . ">$category</option>";
    }
    
    echo "</select></form><table class='widefat fixed striped'><thead><tr>
          <th width='5%'>#</th><th width='8%'>User ID</th><th width='15%'>User</th><th width='35%'>Action</th>
          <th width='17%'>IP Address</th><th width='20%'>Timestamp</th></tr></thead><tbody>";
    
    if (file_exists(LOG_FILE) && ($handle = fopen(LOG_FILE, 'r')) !== false) {
        $header = fgetcsv($handle); // Skip header
        $rows = [];
        while (($data = fgetcsv($handle)) !== false) {
            if ($selected == 'All' || strpos($data[2], $selected) !== false) {
                $rows[] = $data;
            }
        }
        fclose($handle);
        
        $count = count($rows);
        foreach (array_reverse($rows) as $log) {
            $ip_highlight = strpos($log[3], 'Office') !== false ? 'style="color: green; font-weight: bold;"' : '';
            echo "<tr><td>{$count}</td><td>{$log[0]}</td><td>{$log[1]}</td>
                 <td>{$log[2]}</td><td $ip_highlight>{$log[3]}</td><td>{$log[4]}</td></tr>";
            $count--;
        }
    }
    echo "</tbody></table></div>";
}

// IP Access Monitoring
function log_ip_access($username, $status = 'success') {
    $ip = get_user_ip();
    $timestamp = time();
    
    // Check if IP is blocked
    if (is_ip_blocked($ip)) {
        wp_die('Your IP address has been blocked due to suspicious activity. Please contact the administrator at ' . ADMIN_EMAIL);
    }
    
    // Ensure file exists with headers
    if (!file_exists(IP_LOG_FILE)) {
        $file = fopen(IP_LOG_FILE, 'w');
        fputcsv($file, ['IP', 'Username', 'Status', 'Timestamp']);
        fclose($file);
    }
    
    // Append new log entry
    $file = fopen(IP_LOG_FILE, 'a');
    fputcsv($file, [$ip, $username, $status, $timestamp]);
    fclose($file);
    
    // Check for unusual patterns
    check_for_unusual_traffic($ip, $username);
}

function check_for_unusual_traffic($current_ip, $username) {
    if (!file_exists(IP_LOG_FILE)) return;
    
    $file = fopen(IP_LOG_FILE, 'r');
    $header = fgetcsv($file);
    
    $ip_counts = [];
    $failed_attempts = [];
    $current_time = time();
    
    while (($data = fgetcsv($file)) !== false) {
        if (count($data) < 4) continue;
        
        list($ip, $user, $status, $timestamp) = $data;
        
        if ($current_time - $timestamp <= TIME_WINDOW) {
            if (!isset($ip_counts[$ip])) $ip_counts[$ip] = 0;
            $ip_counts[$ip]++;
            
            if ($status === 'failed') {
                if (!isset($failed_attempts[$ip])) $failed_attempts[$ip] = 0;
                $failed_attempts[$ip]++;
            }
        }
    }
    fclose($file);
    
    // Check for rapid access
    if (isset($ip_counts[$current_ip]) && $ip_counts[$current_ip] > 20) {
        $action = "Unusual Traffic Alert: High access frequency from IP $current_ip ({$ip_counts[$current_ip]} requests in " . (TIME_WINDOW/60) . " minutes)";
        track_and_alert($action);
    }
    
    // Check for failed attempts
    if (isset($failed_attempts[$current_ip]) && $failed_attempts[$current_ip] >= MAX_LOGIN_ATTEMPTS) {
        block_ip($current_ip, $username, $failed_attempts[$current_ip]);
        $action = "IP Blocked Alert: IP $current_ip blocked after {$failed_attempts[$current_ip]} failed login attempts";
        track_and_alert($action);
    }
    
    // Check for new IP
    if (strpos($current_ip, 'Office') === false && !in_array($current_ip, get_option('known_ips', []))) {
        $known_ips = get_option('known_ips', []);
        $known_ips[] = $current_ip;
        update_option('known_ips', array_unique($known_ips));
        
        $action = "New IP Access Alert: First time access from IP $current_ip";
        track_and_alert($action);
    }
}

function display_ip_access_logs() {
    echo "<div class='wrap'><h1>IP Access Logs</h1>";
    
    $current_ip = get_user_ip();
    $ip_style = strpos($current_ip, 'Office') !== false ? 'color: green;' : 'color: blue;';
    
    echo "<div class='notice notice-info' style='padding: 15px; background: #f0f8ff;'>";
    echo "<p style='margin: 0;'><strong>🌐 Current IP Detection:</strong> ";
    echo "<span style='$ip_style font-size: 16px; font-weight: bold;'>$current_ip</span></p>";
    echo "</div>";
    
    echo "<p>This page shows recent IP access patterns and highlights potential unusual traffic.</p>";
    
    echo "<table class='widefat fixed striped'><thead><tr>
          <th>IP Address</th><th>Username</th><th>Status</th>
          <th>Timestamp</th></tr></thead><tbody>";
    
    if (file_exists(IP_LOG_FILE) && ($handle = fopen(IP_LOG_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $rows = [];
        
        while (($data = fgetcsv($handle)) !== false) {
            $rows[] = $data;
        }
        fclose($handle);
        
        foreach (array_reverse(array_slice($rows, -100)) as $log) {
            if (count($log) < 4) continue;
            
            $timestamp = date('Y-m-d H:i:s', $log[3]);
            $row_class = $log[2] === 'failed' ? 'style="background-color:#ffeeee;"' : '';
            $ip_style = strpos($log[0], 'Office') !== false ? 'style="color: green; font-weight: bold;"' : '';
            
            echo "<tr $row_class>
                 <td $ip_style>{$log[0]}</td>
                 <td>{$log[1]}</td>
                 <td>{$log[2]}</td>
                 <td>{$timestamp}</td>
                 </tr>";
        }
    }
    echo "</tbody></table></div>";
}

// IP Blocking Functions
function block_ip($ip, $username, $attempt_count) {
    if (!file_exists(BLOCKED_IPS_FILE)) {
        $file = fopen(BLOCKED_IPS_FILE, 'w');
        fputcsv($file, ['IP', 'Username', 'Attempts', 'Blocked Time', 'Reason']);
        fclose($file);
    }
    
    $file = fopen(BLOCKED_IPS_FILE, 'a');
    fputcsv($file, [$ip, $username, $attempt_count, date('Y-m-d H:i:s'), 'Multiple failed login attempts']);
    fclose($file);
}

function is_ip_blocked($ip) {
    if (!file_exists(BLOCKED_IPS_FILE)) return false;
    
    // Clean IP for comparison
    $clean_ip = str_replace(['(Office)', '(Home)'], '', $ip);
    $clean_ip = trim($clean_ip);
    
    $file = fopen(BLOCKED_IPS_FILE, 'r');
    $header = fgetcsv($file);
    
    while (($data = fgetcsv($file)) !== false) {
        $blocked_ip = str_replace(['(Office)', '(Home)'], '', $data[0]);
        $blocked_ip = trim($blocked_ip);
        
        if ($blocked_ip === $clean_ip) {
            fclose($file);
            return true;
        }
    }
    fclose($file);
    return false;
}

function unblock_ip($ip_to_unblock) {
    if (!file_exists(BLOCKED_IPS_FILE)) return false;
    
    $temp_file = BLOCKED_IPS_FILE . '.tmp';
    $file = fopen(BLOCKED_IPS_FILE, 'r');
    $temp = fopen($temp_file, 'w');
    
    $header = fgetcsv($file);
    fputcsv($temp, $header);
    
    $found = false;
    while (($data = fgetcsv($file)) !== false) {
        if ($data[0] !== $ip_to_unblock) {
            fputcsv($temp, $data);
        } else {
            $found = true;
        }
    }
    
    fclose($file);
    fclose($temp);
    
    if ($found) {
        unlink(BLOCKED_IPS_FILE);
        rename($temp_file, BLOCKED_IPS_FILE);
        track_activity("IP Unblocked: $ip_to_unblock");
        return true;
    } else {
        unlink($temp_file);
        return false;
    }
}

function display_blocked_ips() {
    echo "<div class='wrap'><h1>Blocked IP Addresses</h1>";
    
    if (isset($_POST['unblock_ip']) && current_user_can('manage_options')) {
        check_admin_referer('unblock_ip_action', 'unblock_ip_nonce');
        $ip = sanitize_text_field($_POST['unblock_ip']);
        if (unblock_ip($ip)) {
            echo "<div class='notice notice-success'><p>✓ IP address $ip has been unblocked successfully.</p></div>";
        } else {
            echo "<div class='notice notice-error'><p>✗ Failed to unblock IP address $ip.</p></div>";
        }
    }
    
    echo "<p>This page shows all blocked IP addresses. You can unblock them if needed.</p>";
    
    echo "<table class='widefat fixed striped'><thead><tr>
          <th>IP Address</th><th>Username</th><th>Failed Attempts</th>
          <th>Blocked Time</th><th>Reason</th><th>Action</th></tr></thead><tbody>";
    
    if (file_exists(BLOCKED_IPS_FILE) && ($handle = fopen(BLOCKED_IPS_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $has_data = false;
        
        while (($data = fgetcsv($handle)) !== false) {
            $has_data = true;
            echo "<tr>
                 <td>{$data[0]}</td>
                 <td>{$data[1]}</td>
                 <td>{$data[2]}</td>
                 <td>{$data[3]}</td>
                 <td>{$data[4]}</td>
                 <td>
                     <form method='post' style='display:inline;'>
                         " . wp_nonce_field('unblock_ip_action', 'unblock_ip_nonce', true, false) . "
                         <input type='hidden' name='unblock_ip' value='{$data[0]}'>
                         <input type='submit' value='Unblock' class='button button-secondary' 
                                onclick='return confirm(\"Are you sure you want to unblock this IP?\");'>
                     </form>
                 </td>
                 </tr>";
        }
        fclose($handle);
        
        if (!$has_data) {
            echo "<tr><td colspan='6' style='text-align:center;'>No blocked IPs found.</td></tr>";
        }
    } else {
        echo "<tr><td colspan='6' style='text-align:center;'>No blocked IPs found.</td></tr>";
    }
    
    echo "</tbody></table></div>";
}

// Block access for blocked IPs
add_action('init', function() {
    if (is_admin()) return; // Don't block admin users
    
    $current_ip = get_user_ip();
    if (is_ip_blocked($current_ip)) {
        wp_die('Your IP address has been blocked due to suspicious activity. Please contact the administrator at ' . ADMIN_EMAIL);
    }
});

// ============ SECURITY MONITORING - FIXED & WORKING ============

function check_security_changes() {
    // Log that scan is running
    log_activity(0, 'System', 'Security Scan Started');
    
    check_ssl_status();
    check_file_permissions();
    check_security_plugins();
    check_firewall_status();
    
    // Log completion
    log_activity(0, 'System', 'Security Scan Completed');
    
    // Schedule next scan if not scheduled
    if (!wp_next_scheduled('security_scan_hook')) {
        wp_schedule_event(time(), 'daily', 'security_scan_hook');
    }
    
    return true;
}

function check_ssl_status() {
    $is_ssl = is_ssl();
    $force_ssl_admin = defined('FORCE_SSL_ADMIN') && FORCE_SSL_ADMIN;
    $was_ssl = get_option('site_was_ssl', null);
    
    if ($was_ssl === null) {
        update_option('site_was_ssl', $is_ssl);
        log_activity(0, 'System', 'SSL Status Initialized: ' . ($is_ssl ? 'Enabled' : 'Disabled'));
    } else if ($was_ssl && !$is_ssl) {
        track_and_alert("Security Alert: SSL has been disabled for the site");
    } else if (!$was_ssl && $is_ssl) {
        track_activity("Security Update: SSL has been enabled for the site");
    }
    
    $was_ssl_admin = get_option('ssl_admin_was_forced', null);
    if ($was_ssl_admin === null) {
        update_option('ssl_admin_was_forced', $force_ssl_admin);
    } else if ($was_ssl_admin && !$force_ssl_admin) {
        track_and_alert("Security Alert: Forced SSL for admin has been disabled");
    }
    
    update_option('site_was_ssl', $is_ssl);
    update_option('ssl_admin_was_forced', $force_ssl_admin);
}

function check_file_permissions() {
    $wp_config_path = ABSPATH . 'wp-config.php';
    
    if (file_exists($wp_config_path)) {
        $perms = substr(sprintf('%o', fileperms($wp_config_path)), -4);
        $prev_perms = get_option('wp_config_permissions', '');
        
        if (empty($prev_perms)) {
            update_option('wp_config_permissions', $perms);
            log_activity(0, 'System', 'wp-config.php permissions initialized: ' . $perms);
        } else if ($prev_perms !== $perms) {
            track_and_alert("Security Alert: wp-config.php permissions changed from $prev_perms to $perms");
            update_option('wp_config_permissions', $perms);
        }
        
        // Check if permissions are unsafe
        if ($perms[3] > 0) {
            track_and_alert("Security Alert: wp-config.php has unsafe permissions ($perms) - world readable/writable");
        }
    }
    
    $uploads_dir = wp_upload_dir();
    $upload_path = $uploads_dir['basedir'];
    
    if (file_exists($upload_path)) {
        $perms = substr(sprintf('%o', fileperms($upload_path)), -4);
        $prev_perms = get_option('uploads_dir_permissions', '');
        
        if (empty($prev_perms)) {
            update_option('uploads_dir_permissions', $perms);
        } else if ($prev_perms !== $perms && $perms[3] >= 6) {
            track_and_alert("Security Alert: Uploads directory permissions changed to unsafe value ($perms)");
            update_option('uploads_dir_permissions', $perms);
        }
    }
}

function check_security_plugins() {
    $security_plugins = [
        'wordfence/wordfence.php' => 'Wordfence',
        'sucuri-scanner/sucuri.php' => 'Sucuri',
        'better-wp-security/better-wp-security.php' => 'iThemes Security',
        'all-in-one-wp-security-and-firewall/wp-security.php' => 'All In One WP Security'
    ];
    
    $active_plugins = get_option('active_plugins', []);
    $active_security_plugins = array_intersect(array_keys($security_plugins), $active_plugins);
    
    $prev_active_security = get_option('active_security_plugins', []);
    
    if (empty($prev_active_security)) {
        update_option('active_security_plugins', $active_security_plugins);
        log_activity(0, 'System', 'Security plugins status initialized: ' . count($active_security_plugins) . ' active');
    } else {
        $deactivated = array_diff($prev_active_security, $active_security_plugins);
        
        foreach ($deactivated as $plugin) {
            $plugin_name = isset($security_plugins[$plugin]) ? $security_plugins[$plugin] : basename($plugin);
            track_and_alert("Security Alert: Security plugin deactivated: $plugin_name");
        }
        
        update_option('active_security_plugins', $active_security_plugins);
    }
}

function check_firewall_status() {
    $firewall_status = get_firewall_status();
    $prev_status = get_option('firewall_previous_status', null);
    
    if ($prev_status === null) {
        update_option('firewall_previous_status', $firewall_status);
        log_activity(0, 'System', 'Firewall status initialized: ' . ($firewall_status ? 'Active' : 'Inactive'));
    } else if ($prev_status !== $firewall_status) {
        $status_text = $firewall_status ? 'enabled' : 'disabled';
        track_and_alert("Security Alert: Firewall has been $status_text");
        update_option('firewall_previous_status', $firewall_status);
    }
}

function get_firewall_status() {
    // Check if Wordfence firewall is active
    if (function_exists('wfConfig') && class_exists('wfConfig')) {
        try {
            return wfConfig::get('firewallEnabled', false);
        } catch (Exception $e) {
            // Ignore error
        }
    }
    
    // Check if iThemes Security firewall is active
    if (function_exists('itsec_get_settings')) {
        try {
            $settings = itsec_get_settings();
            return isset($settings['active']) && $settings['active'];
        } catch (Exception $e) {
            // Ignore error
        }
    }
    
    // Check if All In One WP Security firewall is active
    if (class_exists('AIO_WP_Security')) {
        try {
            global $aio_wp_security;
            if (isset($aio_wp_security->configs)) {
                return $aio_wp_security->configs->get_value('aiowps_enable_basic_firewall') == '1';
            }
        } catch (Exception $e) {
            // Ignore error
        }
    }
    
    // Check .htaccess for basic firewall rules
    $htaccess_path = ABSPATH . '.htaccess';
    if (file_exists($htaccess_path)) {
        $htaccess_content = file_get_contents($htaccess_path);
        if (strpos($htaccess_content, 'RewriteEngine On') !== false || 
            strpos($htaccess_content, 'deny from') !== false) {
            return true;
        }
    }
    
    return false;
}

function get_outdated_plugins() {
    if (!function_exists('get_plugin_updates')) {
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    wp_update_plugins();
    $updates = get_plugin_updates();
    
    return $updates;
}

function display_outdated_plugins() {
    echo "<div class='wrap'><h1>Outdated Plugins</h1>";
    
    $outdated = get_outdated_plugins();
    
    if (empty($outdated)) {
        echo "<div class='notice notice-success'><p><strong>✓ All plugins are up to date!</strong></p></div>";
    } else {
        echo "<div class='notice notice-warning'><p><strong>⚠ The following plugins have updates available:</strong></p></div>";
        echo "<table class='widefat fixed striped'><thead><tr>
              <th>Plugin Name</th><th>Current Version</th><th>New Version</th>
              <th>Action</th></tr></thead><tbody>";
        
        foreach ($outdated as $plugin_file => $plugin_data) {
            $plugin_name = $plugin_data->Name;
            $current_version = $plugin_data->Version;
            $new_version = $plugin_data->update->new_version;
            $update_url = wp_nonce_url(
                self_admin_url('update.php?action=upgrade-plugin&plugin=' . urlencode($plugin_file)),
                'upgrade-plugin_' . $plugin_file
            );
            
            echo "<tr>
                 <td><strong>$plugin_name</strong></td>
                 <td>$current_version</td>
                 <td><span style='color:red; font-weight:bold;'>$new_version</span></td>
                 <td><a href='$update_url' class='button button-primary'>Update Now</a></td>
                 </tr>";
        }
        
        echo "</tbody></table>";
    }
    
    echo "</div>";
}

function display_security_monitor() {
    echo "<div class='wrap'><h1>🔒 Security Monitor</h1>";
    
    // Handle manual security scan
    if (isset($_POST['run_security_scan']) && current_user_can('manage_options')) {
        check_admin_referer('security_scan_action', 'security_scan_nonce');
        
        $result = check_security_changes();
        
        if ($result) {
            echo "<div class='notice notice-success is-dismissible'><p><strong>✓ Security scan completed successfully!</strong> Check Activity Logs for detailed results.</p></div>";
        } else {
            echo "<div class='notice notice-error'><p><strong>✗ Security scan encountered an error.</strong></p></div>";
        }
    }
    
    // Scan button with proper nonce
    echo "<div style='margin: 20px 0; padding: 15px; background: #f0f8ff; border-left: 4px solid #0073aa;'>";
    echo "<form method='post' style='display: inline;'>";
    wp_nonce_field('security_scan_action', 'security_scan_nonce');
    echo "<input type='submit' name='run_security_scan' value='🔍 Run Security Scan Now' class='button button-primary button-large'>";
    echo "</form>";
    
    $last_scan = get_option('last_security_scan', 0);
    if ($last_scan > 0) {
        $last_scan_time = date('Y-m-d H:i:s', $last_scan);
        $time_ago = human_time_diff($last_scan, current_time('timestamp')) . ' ago';
        echo "<p style='margin: 10px 0 0 0;'><strong>Last Scan:</strong> $last_scan_time ($time_ago)</p>";
    } else {
        echo "<p style='margin: 10px 0 0 0;'><em>No scan has been performed yet.</em></p>";
    }
    echo "</div>";
    
    // Security Status Table
    $is_ssl = is_ssl();
    $force_ssl_admin = defined('FORCE_SSL_ADMIN') && FORCE_SSL_ADMIN;
    $ssl_status = $is_ssl ? '<span style="color:green; font-weight:bold;">✓ Enabled</span>' : '<span style="color:red; font-weight:bold;">✗ Disabled</span>';
    $admin_ssl_status = $force_ssl_admin ? '<span style="color:green; font-weight:bold;">✓ Forced</span>' : '<span style="color:red; font-weight:bold;">✗ Not Forced</span>';
    
    // Firewall Status
    $firewall_active = get_firewall_status();
    $firewall_status = $firewall_active ? '<span style="color:green; font-weight:bold;">✓ Active</span>' : '<span style="color:red; font-weight:bold;">✗ Inactive</span>';
    
    // File Permissions
    $wp_config_path = ABSPATH . 'wp-config.php';
    $perms = file_exists($wp_config_path) ? substr(sprintf('%o', fileperms($wp_config_path)), -4) : 'N/A';
    $perms_status = $perms != 'N/A' && $perms[3] == 0 ? '<span style="color:green; font-weight:bold;">✓ Secure (' . $perms . ')</span>' : '<span style="color:red; font-weight:bold;">✗ Insecure (' . $perms . ')</span>';
    
    // Security Plugins
    $security_plugins = [
        'wordfence/wordfence.php' => 'Wordfence',
        'sucuri-scanner/sucuri.php' => 'Sucuri',
        'better-wp-security/better-wp-security.php' => 'iThemes Security',
        'all-in-one-wp-security-and-firewall/wp-security.php' => 'All In One WP Security'
    ];
    
    $active_plugins = get_option('active_plugins', []);
    $active_security = [];
    
    foreach ($security_plugins as $plugin_file => $plugin_name) {
        if (in_array($plugin_file, $active_plugins)) {
            $active_security[] = "$plugin_name <span style='color:green; font-weight:bold;'>✓</span>";
        } else {
            $active_security[] = "$plugin_name <span style='color:red;'>✗</span>";
        }
    }
    
    // Check for outdated plugins
    $outdated = get_outdated_plugins();
    $outdated_count = count($outdated);
    $outdated_status = $outdated_count > 0 ? 
        "<span style='color:red; font-weight:bold;'>⚠ $outdated_count plugin(s) need update</span>" : 
        "<span style='color:green; font-weight:bold;'>✓ All up to date</span>";
    
    echo "<h2>Security Status Dashboard</h2>";
    echo "<table class='widefat fixed striped' style='margin-top: 20px;'>";
    echo "<thead><tr><th width='30%'>Security Check</th><th width='70%'>Status</th></tr></thead>";
    echo "<tbody>";
    echo "<tr><th>SSL/HTTPS Status</th><td>$ssl_status</td></tr>";
    echo "<tr><th>Admin SSL Enforcement</th><td>$admin_ssl_status</td></tr>";
    echo "<tr><th>Firewall Status</th><td>$firewall_status</td></tr>";
    echo "<tr><th>wp-config.php Permissions</th><td>$perms_status</td></tr>";
    echo "<tr><th>Security Plugins</th><td>" . implode('<br>', $active_security) . "</td></tr>";
    echo "<tr><th>Plugin Updates</th><td>$outdated_status</td></tr>";
    echo "</tbody></table>";
    
    echo "<div style='margin-top: 20px; padding: 15px; background: #fffbcc; border-left: 4px solid #ffb900;'>";
    echo "<h3 style='margin-top: 0;'>ℹ️ Security Scan Information</h3>";
    echo "<ul style='margin: 10px 0;'>";
    echo "<li>Security scans run automatically once per day</li>";
    echo "<li>You can manually trigger a scan using the button above</li>";
    echo "<li>All security changes are logged and email alerts are sent</li>";
    echo "<li>Check Activity Logs for detailed security events</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "</div>";
}

// Contact Form Integration
function log_contact_form_submission($contact_form) {
    if (!class_exists('WPCF7_Submission')) return;
    
    $submission = WPCF7_Submission::get_instance();
    if (!$submission) return;
    
    $posted_data = $submission->get_posted_data();
    
    if (!file_exists(CONTACT_FORM_LOG_FILE)) {
        $file = fopen(CONTACT_FORM_LOG_FILE, 'w');
        fputcsv($file, ['Form ID', 'Form Title', 'Name', 'Email', 'Phone', 'Message', 'IP Address', 'Timestamp']);
        fclose($file);
    }
    
    $name = isset($posted_data['your-name']) ? sanitize_text_field($posted_data['your-name']) : 
            (isset($posted_data['name']) ? sanitize_text_field($posted_data['name']) : 'N/A');
    
    $email = isset($posted_data['your-email']) ? sanitize_email($posted_data['your-email']) : 
             (isset($posted_data['email']) ? sanitize_email($posted_data['email']) : 'N/A');
    
    $phone = isset($posted_data['your-phone']) ? sanitize_text_field($posted_data['your-phone']) : 
             (isset($posted_data['phone']) ? sanitize_text_field($posted_data['phone']) : 'N/A');
    
    $message = isset($posted_data['your-message']) ? sanitize_textarea_field($posted_data['your-message']) : 
               (isset($posted_data['message']) ? sanitize_textarea_field($posted_data['message']) : 'N/A');
    
    $file = fopen(CONTACT_FORM_LOG_FILE, 'a');
    fputcsv($file, [
        $contact_form->id(),
        $contact_form->title(),
        $name,
        $email,
        $phone,
        $message,
        get_user_ip(),
        date('Y-m-d H:i:s')
    ]);
    fclose($file);
}

add_action('wpcf7_before_send_mail', 'log_contact_form_submission');

// WPForms Integration
add_action('wpforms_process_complete', function($fields, $entry, $form_data) {
    if (!file_exists(CONTACT_FORM_LOG_FILE)) {
        $file = fopen(CONTACT_FORM_LOG_FILE, 'w');
        fputcsv($file, ['Form ID', 'Form Title', 'Name', 'Email', 'Phone', 'Message', 'IP Address', 'Timestamp']);
        fclose($file);
    }
    
    $name = '';
    $email = '';
    $phone = '';
    $message = '';
    
    foreach ($fields as $field) {
        if (isset($field['type'])) {
            switch ($field['type']) {
                case 'name':
                    $name = isset($field['value']) ? sanitize_text_field($field['value']) : '';
                    break;
                case 'email':
                    $email = isset($field['value']) ? sanitize_email($field['value']) : '';
                    break;
                case 'phone':
                    $phone = isset($field['value']) ? sanitize_text_field($field['value']) : '';
                    break;
                case 'textarea':
                    $message = isset($field['value']) ? sanitize_textarea_field($field['value']) : '';
                    break;
            }
        }
    }
    
    $file = fopen(CONTACT_FORM_LOG_FILE, 'a');
    fputcsv($file, [
        $form_data['id'],
        $form_data['settings']['form_title'],
        $name,
        $email,
        $phone,
        $message,
        get_user_ip(),
        date('Y-m-d H:i:s')
    ]);
    fclose($file);
}, 10, 3);

// Gravity Forms Integration
add_action('gform_after_submission', function($entry, $form) {
    if (!file_exists(CONTACT_FORM_LOG_FILE)) {
        $file = fopen(CONTACT_FORM_LOG_FILE, 'w');
        fputcsv($file, ['Form ID', 'Form Title', 'Name', 'Email', 'Phone', 'Message', 'IP Address', 'Timestamp']);
        fclose($file);
    }
    
    $name = '';
    $email = '';
    $phone = '';
    $message = '';
    
    foreach ($form['fields'] as $field) {
        $value = rgar($entry, $field->id);
        
        if ($field->type == 'name') {
            $name = $value;
        } elseif ($field->type == 'email') {
            $email = $value;
        } elseif ($field->type == 'phone') {
            $phone = $value;
        } elseif ($field->type == 'textarea') {
            $message = $value;
        }
    }
    
    $file = fopen(CONTACT_FORM_LOG_FILE, 'a');
    fputcsv($file, [
        $form['id'],
        $form['title'],
        sanitize_text_field($name),
        sanitize_email($email),
        sanitize_text_field($phone),
        sanitize_textarea_field($message),
        get_user_ip(),
        date('Y-m-d H:i:s')
    ]);
    fclose($file);
}, 10, 2);

function display_contact_form_logs() {
    echo "<div class='wrap'><h1>📧 Contact Form Submissions</h1>";
    echo "<p>This page shows all contact form submissions from your website.</p>";
    
    echo "<table class='widefat fixed striped' style='table-layout: fixed;'><thead><tr>
          <th style='width: 5%;'>#</th>
          <th style='width: 8%;'>Form ID</th>
          <th style='width: 12%;'>Form Title</th>
          <th style='width: 12%;'>Name</th>
          <th style='width: 15%;'>Email</th>
          <th style='width: 10%;'>Phone</th>
          <th style='width: 20%;'>Message</th>
          <th style='width: 10%;'>IP Address</th>
          <th style='width: 12%;'>Timestamp</th>
          </tr></thead><tbody>";
    
    if (file_exists(CONTACT_FORM_LOG_FILE) && ($handle = fopen(CONTACT_FORM_LOG_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $rows = [];
        
        while (($data = fgetcsv($handle)) !== false) {
            $rows[] = $data;
        }
        fclose($handle);
        
        if (empty($rows)) {
            echo "<tr><td colspan='9' style='text-align:center;'>No contact form submissions found.</td></tr>";
        } else {
            $count = count($rows);
            foreach (array_reverse($rows) as $log) {
                $message_preview = strlen($log[5]) > 50 ? substr($log[5], 0, 50) . '...' : $log[5];
                
                echo "<tr>
                     <td>{$count}</td>
                     <td>{$log[0]}</td>
                     <td>{$log[1]}</td>
                     <td>{$log[2]}</td>
                     <td>{$log[3]}</td>
                     <td>{$log[4]}</td>
                     <td title='" . esc_attr($log[5]) . "' style='overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'>{$message_preview}</td>
                     <td>{$log[6]}</td>
                     <td>{$log[7]}</td>
                     </tr>";
                $count--;
            }
        }
    } else {
        echo "<tr><td colspan='9' style='text-align:center;'>No contact form submissions found.</td></tr>";
    }
    
    echo "</tbody></table></div>";
}

// Register security scan hook
add_action('security_scan_hook', 'check_security_changes');

// Plugin activation
register_activation_hook(__FILE__, function() {
    // Initialize all CSV files
    $files_config = [
        LOG_FILE => ['User ID', 'Username', 'Action', 'IP Address', 'Timestamp'],
        IP_LOG_FILE => ['IP', 'Username', 'Status', 'Timestamp'],
        BLOCKED_IPS_FILE => ['IP', 'Username', 'Attempts', 'Blocked Time', 'Reason'],
        CONTACT_FORM_LOG_FILE => ['Form ID', 'Form Title', 'Name', 'Email', 'Phone', 'Message', 'IP Address', 'Timestamp']
    ];
    
    foreach ($files_config as $file_path => $headers) {
        if (!file_exists($file_path)) {
            $file = fopen($file_path, 'w');
            fputcsv($file, $headers);
            fclose($file);
        }
    }
    
    // Run initial security check
    check_security_changes();
    update_option('last_security_scan', time());
    
    // Schedule daily security scan
    if (!wp_next_scheduled('security_scan_hook')) {
        wp_schedule_event(time(), 'daily', 'security_scan_hook');
    }
    
    log_activity(0, 'System', 'Activity Logger Plugin Activated');
});

// Plugin deactivation
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('security_scan_hook');
    log_activity(0, 'System', 'Activity Logger Plugin Deactivated');
});

// Run security check on admin init (limited to once per day)
add_action('admin_init', function() {
    $last_scan = get_option('last_security_scan', 0);
    if (time() - $last_scan > SECURITY_SCAN_INTERVAL) {
        check_security_changes();
        update_option('last_security_scan', time());
    }
});