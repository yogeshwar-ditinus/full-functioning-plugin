<?php
/**
 * Plugin Name: MSDP Remote Connector v5.2 - Fixed & Enhanced
 * Description: Complete security enforcement with proper file editor blocking, personal data tools control, and management features
 * Version: 5.2.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) exit;

class MSDP_Remote_Connector_V52 {
    private static $instance = null;
    
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // REST API endpoints
        add_action('rest_api_init', [$this, 'register_endpoints']);
        
        // Security enforcement - CRITICAL: This must run early
        add_action('init', [$this, 'enforce_security'], 1);
        add_action('admin_init', [$this, 'block_editor_access'], 1);
        
        // Failed login tracking
        add_action('wp_login_failed', [$this, 'log_failed_login']);
        
        // Activity tracking
        $this->setup_activity_tracking();
    }
    
    /**
     * Register REST API Endpoints
     */
    public function register_endpoints() {
        $namespace = 'msdp/v1';
        
        // Security Features
        register_rest_route($namespace, '/security/file-editor', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_file_editor'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/personal-data', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_personal_data_tools'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/hide-version', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_wp_version'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/file-protection', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_file_protection'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/login-url', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_login_url'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Management Features
        register_rest_route($namespace, '/manage/plugins', [
            'methods' => 'GET',
            'callback' => [$this, 'get_plugins_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/themes', [
            'methods' => 'GET',
            'callback' => [$this, 'get_themes_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/posts', [
            'methods' => 'GET',
            'callback' => [$this, 'get_posts_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/pages', [
            'methods' => 'GET',
            'callback' => [$this, 'get_pages_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/media', [
            'methods' => 'GET',
            'callback' => [$this, 'get_media_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/users', [
            'methods' => 'GET',
            'callback' => [$this, 'get_users_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Connection test
        register_rest_route($namespace, '/test', [
            'methods' => 'GET',
            'callback' => [$this, 'test_connection'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Activity log
        register_rest_route($namespace, '/activity', [
            'methods' => 'GET',
            'callback' => [$this, 'get_activity_log'],
            'permission_callback' => [$this, 'check_permission']
        ]);
    }
    
    /**
     * Check Permission
     */
    public function check_permission($request) {
        return current_user_can('manage_options');
    }
    
    /**
     * CRITICAL: Enforce Security Settings
     * यह function early load होता है और सभी security settings को enforce करता है
     */
    public function enforce_security() {
        // File Editor - CRITICAL FIX
        if (get_option('msdp_file_editor_disabled', 0)) {
            // Method 1: Define constant
            if (!defined('DISALLOW_FILE_EDIT')) {
                define('DISALLOW_FILE_EDIT', true);
            }
            
            // Method 2: Remove capability filter
            add_filter('user_has_cap', [$this, 'remove_editor_capability'], 10, 4);
        }
        
        // Personal Data Tools
        if (get_option('msdp_personal_data_tools_disabled', 0)) {
            add_filter('user_has_cap', [$this, 'remove_privacy_capability'], 10, 4);
        }
        
        // Hide WordPress version
        if (get_option('msdp_hide_wp_version', 0)) {
            remove_action('wp_head', 'wp_generator');
            add_filter('the_generator', '__return_empty_string');
        }
        
        // Check blocked IP
        $this->check_blocked_ip();
    }
    
    /**
     * CRITICAL FIX: Block Editor Access via Capability
     * यह सबसे effective method है file editor को block करने के लिए
     */
    public function remove_editor_capability($allcaps, $caps, $args, $user) {
        // Remove edit_themes and edit_plugins capability
        if (isset($allcaps['edit_themes'])) {
            $allcaps['edit_themes'] = false;
        }
        if (isset($allcaps['edit_plugins'])) {
            $allcaps['edit_plugins'] = false;
        }
        return $allcaps;
    }
    
    /**
     * CRITICAL FIX: Remove Personal Data Export/Erase Capabilities
     */
    public function remove_privacy_capability($allcaps, $caps, $args, $user) {
        // Remove capabilities for personal data tools
        if (isset($allcaps['export_others_personal_data'])) {
            $allcaps['export_others_personal_data'] = false;
        }
        if (isset($allcaps['erase_others_personal_data'])) {
            $allcaps['erase_others_personal_data'] = false;
        }
        if (isset($allcaps['manage_privacy_options'])) {
            $allcaps['manage_privacy_options'] = false;
        }
        return $allcaps;
    }
    
    /**
     * CRITICAL FIX: Block Direct Editor Access
     * यह admin_init पर run होता है और direct access को block करता है
     */
    public function block_editor_access() {
        global $pagenow;
        
        // File Editor blocked
        if (get_option('msdp_file_editor_disabled', 0)) {
            if ($pagenow === 'theme-editor.php' || $pagenow === 'plugin-editor.php') {
                wp_die(
                    '<h1>Editor Disabled</h1><p>The theme and plugin editors have been disabled by your administrator.</p>',
                    'Editor Disabled',
                    ['response' => 403, 'back_link' => true]
                );
            }
            
            // Remove menu items
            remove_submenu_page('themes.php', 'theme-editor.php');
            remove_submenu_page('plugins.php', 'plugin-editor.php');
        }
        
        // Personal Data Tools blocked
        if (get_option('msdp_personal_data_tools_disabled', 0)) {
            if ($pagenow === 'export-personal-data.php' || $pagenow === 'erase-personal-data.php') {
                wp_die(
                    '<h1>Access Denied</h1><p>Personal data tools have been disabled by your administrator.</p>',
                    'Access Denied',
                    ['response' => 403, 'back_link' => true]
                );
            }
            
            // Remove menu items
            remove_submenu_page('tools.php', 'export-personal-data.php');
            remove_submenu_page('tools.php', 'erase-personal-data.php');
        }
    }
    
    /**
     * Handle File Editor Toggle
     */
    public function handle_file_editor($request) {
        if ($request->get_method() === 'POST') {
            $enable = $request->get_param('enabled');
            
            if (!$enable) {
                // DISABLE file editor - Complete enforcement
                $this->add_constant_to_config('DISALLOW_FILE_EDIT', 'true');
                update_option('msdp_file_editor_disabled', 1);
                
                // Log the action
                $this->log_action('file_editor_disabled', 'File editor has been disabled');
                
            } else {
                // ENABLE file editor
                $this->remove_constant_from_config('DISALLOW_FILE_EDIT');
                update_option('msdp_file_editor_disabled', 0);
                
                // Log the action
                $this->log_action('file_editor_enabled', 'File editor has been enabled');
            }
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => $enable,
                'message' => $enable ? 'File editor enabled successfully' : 'File editor disabled successfully'
            ]);
        }
        
        // GET - return current status
        $disabled = get_option('msdp_file_editor_disabled', 0);
        return rest_ensure_response([
            'enabled' => !$disabled,
            'constant_defined' => defined('DISALLOW_FILE_EDIT'),
            'status' => $disabled ? 'disabled' : 'enabled'
        ]);
    }
    
    /**
     * Handle Personal Data Tools Toggle
     */
    public function handle_personal_data_tools($request) {
        if ($request->get_method() === 'POST') {
            $enable = $request->get_param('enabled');
            
            if (!$enable) {
                // DISABLE personal data tools
                update_option('msdp_personal_data_tools_disabled', 1);
                $this->log_action('personal_data_disabled', 'Personal data tools have been disabled');
            } else {
                // ENABLE personal data tools
                update_option('msdp_personal_data_tools_disabled', 0);
                $this->log_action('personal_data_enabled', 'Personal data tools have been enabled');
            }
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => $enable,
                'message' => $enable ? 'Personal data tools enabled' : 'Personal data tools disabled'
            ]);
        }
        
        // GET - return current status
        $disabled = get_option('msdp_personal_data_tools_disabled', 0);
        return rest_ensure_response([
            'enabled' => !$disabled,
            'status' => $disabled ? 'disabled' : 'enabled'
        ]);
    }
    
    /**
     * Handle WordPress Version Hiding
     */
    public function handle_wp_version($request) {
        if ($request->get_method() === 'POST') {
            $hide = !$request->get_param('enabled'); // Note: enabled means visible
            
            update_option('msdp_hide_wp_version', $hide ? 1 : 0);
            $this->log_action('wp_version_' . ($hide ? 'hidden' : 'visible'), 'WordPress version visibility changed');
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => !$hide,
                'message' => $hide ? 'WordPress version hidden' : 'WordPress version visible'
            ]);
        }
        
        // GET - return current status
        $hidden = get_option('msdp_hide_wp_version', 0);
        return rest_ensure_response([
            'enabled' => !$hidden,
            'status' => $hidden ? 'hidden' : 'visible'
        ]);
    }
    
    /**
     * Handle File Protection
     */
    public function handle_file_protection($request) {
        if ($request->get_method() === 'POST') {
            $enable = $request->get_param('enabled');
            
            if ($enable) {
                $result = $this->create_htaccess_protection();
                update_option('msdp_file_protection_enabled', 1);
                $this->log_action('file_protection_enabled', 'File protection enabled');
            } else {
                $result = $this->remove_htaccess_protection();
                update_option('msdp_file_protection_enabled', 0);
                $this->log_action('file_protection_disabled', 'File protection disabled');
            }
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => $enable,
                'message' => $enable ? 'File protection enabled' : 'File protection disabled',
                'htaccess_result' => $result
            ]);
        }
        
        // GET - return current status
        $enabled = get_option('msdp_file_protection_enabled', 0);
        return rest_ensure_response([
            'enabled' => (bool)$enabled,
            'status' => $enabled ? 'enabled' : 'disabled'
        ]);
    }
    
    /**
     * Handle Custom Login URL
     */
    public function handle_login_url($request) {
        if ($request->get_method() === 'POST') {
            $slug = sanitize_title($request->get_param('slug'));
            
            if (empty($slug)) {
                return rest_ensure_response([
                    'success' => false,
                    'message' => 'Login slug cannot be empty'
                ]);
            }
            
            update_option('msdp_custom_login_slug', $slug);
            $this->log_action('login_url_changed', 'Custom login URL set to: ' . $slug);
            
            return rest_ensure_response([
                'success' => true,
                'slug' => $slug,
                'message' => 'Login URL changed successfully',
                'new_url' => home_url($slug)
            ]);
        }
        
        // GET - return current slug
        $slug = get_option('msdp_custom_login_slug', '');
        return rest_ensure_response([
            'slug' => $slug,
            'current_url' => $slug ? home_url($slug) : wp_login_url()
        ]);
    }
    
    /**
     * Get Plugins Information
     */
    public function get_plugins_info() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins', []);
        
        $total = count($all_plugins);
        $active = count($active_plugins);
        $inactive = $total - $active;
        
        return rest_ensure_response([
            'success' => true,
            'total' => $total,
            'active' => $active,
            'inactive' => $inactive,
            'plugins' => array_values(array_map(function($file, $data) use ($active_plugins) {
                return [
                    'name' => $data['Name'],
                    'version' => $data['Version'],
                    'active' => in_array($file, $active_plugins)
                ];
            }, array_keys($all_plugins), $all_plugins)),
            'admin_url' => admin_url('plugins.php')
        ]);
    }
    
    /**
     * Get Themes Information
     */
    public function get_themes_info() {
        $all_themes = wp_get_themes();
        $current_theme = wp_get_theme();
        
        return rest_ensure_response([
            'success' => true,
            'total' => count($all_themes),
            'current' => $current_theme->get('Name'),
            'current_version' => $current_theme->get('Version'),
            'themes' => array_values(array_map(function($theme) use ($current_theme) {
                return [
                    'name' => $theme->get('Name'),
                    'version' => $theme->get('Version'),
                    'active' => $theme->get_stylesheet() === $current_theme->get_stylesheet()
                ];
            }, array_values($all_themes))),
            'admin_url' => admin_url('themes.php')
        ]);
    }
    
    /**
     * Get Posts Information
     */
    public function get_posts_info() {
        $posts = wp_count_posts('post');
        
        return rest_ensure_response([
            'success' => true,
            'total' => $posts->publish + $posts->draft + $posts->pending,
            'published' => $posts->publish,
            'draft' => $posts->draft,
            'pending' => $posts->pending,
            'admin_url' => admin_url('edit.php')
        ]);
    }
    
    /**
     * Get Pages Information
     */
    public function get_pages_info() {
        $pages = wp_count_posts('page');
        
        return rest_ensure_response([
            'success' => true,
            'total' => $pages->publish + $pages->draft + $pages->pending,
            'published' => $pages->publish,
            'draft' => $pages->draft,
            'pending' => $pages->pending,
            'admin_url' => admin_url('edit.php?post_type=page')
        ]);
    }
    
    /**
     * Get Media Information
     */
    public function get_media_info() {
        $media = wp_count_posts('attachment');
        
        return rest_ensure_response([
            'success' => true,
            'total' => $media->inherit,
            'images' => $this->count_media_by_type('image'),
            'videos' => $this->count_media_by_type('video'),
            'documents' => $this->count_media_by_type('application'),
            'admin_url' => admin_url('upload.php')
        ]);
    }
    
    /**
     * Get Users Information
     */
    public function get_users_info() {
        $users = count_users();
        
        return rest_ensure_response([
            'success' => true,
            'total' => $users['total_users'],
            'roles' => $users['avail_roles'],
            'admin_url' => admin_url('users.php')
        ]);
    }
    
    /**
     * Count Media by Type
     */
    private function count_media_by_type($type) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = 'attachment' AND post_mime_type LIKE %s",
            $type . '%'
        ));
    }
    
    /**
     * Test Connection
     */
    public function test_connection() {
        return rest_ensure_response([
            'success' => true,
            'message' => 'Connection successful',
            'site_url' => get_site_url(),
            'rest_url' => get_rest_url(),
            'wp_version' => get_bloginfo('version'),
            'timestamp' => current_time('mysql')
        ]);
    }
    
    /**
     * Get Activity Log
     */
    public function get_activity_log() {
        $logs = get_option('msdp_activity_log', []);
        $logs = array_slice($logs, -50); // Last 50 entries
        
        return rest_ensure_response([
            'success' => true,
            'logs' => $logs
        ]);
    }
    
    /**
     * Add Constant to wp-config.php
     */
    private function add_constant_to_config($constant, $value) {
        $config_file = ABSPATH . 'wp-config.php';
        
        if (!file_exists($config_file) || !is_writable($config_file)) {
            return false;
        }
        
        $config = file_get_contents($config_file);
        
        // Remove existing definition if present
        $config = preg_replace(
            "/define\s*\(\s*['\"]" . $constant . "['\"]\s*,\s*.*?\s*\)\s*;/",
            '',
            $config
        );
        
        // Add new definition before /* That's all, stop editing! */
        $new_constant = "define('" . $constant . "', " . $value . ");\n";
        $config = str_replace(
            "/* That's all, stop editing!",
            $new_constant . "/* That's all, stop editing!",
            $config
        );
        
        return file_put_contents($config_file, $config);
    }
    
    /**
     * Remove Constant from wp-config.php
     */
    private function remove_constant_from_config($constant) {
        $config_file = ABSPATH . 'wp-config.php';
        
        if (!file_exists($config_file) || !is_writable($config_file)) {
            return false;
        }
        
        $config = file_get_contents($config_file);
        
        // Remove the constant definition
        $config = preg_replace(
            "/define\s*\(\s*['\"]" . $constant . "['\"]\s*,\s*.*?\s*\)\s*;\n?/",
            '',
            $config
        );
        
        return file_put_contents($config_file, $config);
    }
    
    /**
     * Create .htaccess Protection
     */
    private function create_htaccess_protection() {
        $htaccess_file = ABSPATH . '.htaccess';
        
        if (!file_exists($htaccess_file)) {
            return false;
        }
        
        $protection_rules = "\n# MSDP Security Protection - START\n";
        $protection_rules .= "<Files wp-config.php>\n";
        $protection_rules .= "Order deny,allow\n";
        $protection_rules .= "Deny from all\n";
        $protection_rules .= "</Files>\n";
        $protection_rules .= "<Files readme.html>\n";
        $protection_rules .= "Order deny,allow\n";
        $protection_rules .= "Deny from all\n";
        $protection_rules .= "</Files>\n";
        $protection_rules .= "<Files license.txt>\n";
        $protection_rules .= "Order deny,allow\n";
        $protection_rules .= "Deny from all\n";
        $protection_rules .= "</Files>\n";
        $protection_rules .= "<Files xmlrpc.php>\n";
        $protection_rules .= "Order deny,allow\n";
        $protection_rules .= "Deny from all\n";
        $protection_rules .= "</Files>\n";
        $protection_rules .= "# MSDP Security Protection - END\n";
        
        $current_htaccess = file_get_contents($htaccess_file);
        
        // Remove old protection if exists
        $current_htaccess = preg_replace(
            '/# MSDP Security Protection - START.*?# MSDP Security Protection - END\n/s',
            '',
            $current_htaccess
        );
        
        // Add new protection at the top
        $new_htaccess = $protection_rules . $current_htaccess;
        
        return file_put_contents($htaccess_file, $new_htaccess);
    }
    
    /**
     * Remove .htaccess Protection
     */
    private function remove_htaccess_protection() {
        $htaccess_file = ABSPATH . '.htaccess';
        
        if (!file_exists($htaccess_file)) {
            return false;
        }
        
        $current_htaccess = file_get_contents($htaccess_file);
        
        // Remove protection rules
        $new_htaccess = preg_replace(
            '/# MSDP Security Protection - START.*?# MSDP Security Protection - END\n/s',
            '',
            $current_htaccess
        );
        
        return file_put_contents($htaccess_file, $new_htaccess);
    }
    
    /**
     * Check Blocked IP
     */
    private function check_blocked_ip() {
        $blocked_ips = get_option('msdp_blocked_ips', []);
        $current_ip = $this->get_client_ip();
        
        if (in_array($current_ip, $blocked_ips)) {
            wp_die(
                '<h1>Access Denied</h1><p>Your IP address has been blocked.</p>',
                'Access Denied',
                ['response' => 403]
            );
        }
    }
    
    /**
     * Get Client IP
     */
    private function get_client_ip() {
        $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && filter_var($_SERVER[$key], FILTER_VALIDATE_IP)) {
                return $_SERVER[$key];
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Log Failed Login
     */
    public function log_failed_login($username) {
        $ip = $this->get_client_ip();
        $attempts = get_option('msdp_login_attempts', []);
        
        if (!isset($attempts[$ip])) {
            $attempts[$ip] = ['count' => 0, 'username' => $username, 'time' => time()];
        }
        
        $attempts[$ip]['count']++;
        $attempts[$ip]['last_attempt'] = time();
        $attempts[$ip]['username'] = $username;
        
        // Block after 4 attempts
        if ($attempts[$ip]['count'] >= 4) {
            $blocked_ips = get_option('msdp_blocked_ips', []);
            if (!in_array($ip, $blocked_ips)) {
                $blocked_ips[] = $ip;
                update_option('msdp_blocked_ips', $blocked_ips);
                $this->log_action('ip_blocked', "IP $ip blocked after {$attempts[$ip]['count']} failed login attempts");
            }
        }
        
        update_option('msdp_login_attempts', $attempts);
    }
    
    /**
     * Setup Activity Tracking
     */
    private function setup_activity_tracking() {
        // Track user actions
        add_action('user_register', function($user_id) {
            $user = get_userdata($user_id);
            $this->log_action('user_created', "User created: {$user->user_login}");
        });
        
        add_action('delete_user', function($user_id) {
            $user = get_userdata($user_id);
            $this->log_action('user_deleted', "User deleted: {$user->user_login}");
        });
        
        // Track plugin actions
        add_action('activated_plugin', function($plugin) {
            $this->log_action('plugin_activated', "Plugin activated: $plugin");
        });
        
        add_action('deactivated_plugin', function($plugin) {
            $this->log_action('plugin_deactivated', "Plugin deactivated: $plugin");
        });
        
        // Track theme changes
        add_action('switch_theme', function($new_name, $new_theme) {
            $this->log_action('theme_switched', "Theme switched to: $new_name");
        }, 10, 2);
        
        // Track post/page actions
        add_action('save_post', function($post_id, $post) {
            if ($post->post_status === 'publish') {
                $this->log_action('content_published', "Published: {$post->post_title} ({$post->post_type})");
            }
        }, 10, 2);
        
        add_action('before_delete_post', function($post_id) {
            $post = get_post($post_id);
            $this->log_action('content_deleted', "Deleted: {$post->post_title} ({$post->post_type})");
        });
    }
    
    /**
     * Log Action
     */
    private function log_action($action, $description) {
        $logs = get_option('msdp_activity_log', []);
        
        $logs[] = [
            'action' => $action,
            'description' => $description,
            'user' => wp_get_current_user()->user_login ?? 'System',
            'ip' => $this->get_client_ip(),
            'time' => current_time('mysql'),
            'timestamp' => time()
        ];
        
        // Keep only last 100 logs
        $logs = array_slice($logs, -100);
        
        update_option('msdp_activity_log', $logs);
    }
}

// Initialize
MSDP_Remote_Connector_V52::instance();
