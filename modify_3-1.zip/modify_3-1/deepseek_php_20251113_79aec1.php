<?php
/**
 * Plugin Name: Activity Logger Pro - Fixed 2FA
 * Plugin URI: https://yourwebsite.com
 * Description: Complete security monitoring with 2FA, login URL change, file editing control, and more.
 * Version: 4.1
 * Author: Veer Saini
 * Author URI: https://viyog.com
 */

if (!defined('ABSPATH')) exit;

// Constants
define('AL_LOG_FILE', __DIR__ . '/activity_logs.csv');
define('AL_IP_LOG_FILE', __DIR__ . '/ip_access_logs.csv');
define('AL_BLOCKED_IPS_FILE', __DIR__ . '/blocked_ips.csv');
define('AL_CONTACT_FORM_LOG_FILE', __DIR__ . '/contact_form_logs.csv');
define('AL_ADMIN_EMAIL', 'yogeshwarsaini321@gmail.com');
define('AL_OFFICE_IPS', ['192.168.20.8', '192.168.18.113']);
define('AL_MAX_LOGIN_ATTEMPTS', 5);
define('AL_TIME_WINDOW', 3600);
define('AL_SECURITY_SCAN_INTERVAL', 86400);
date_default_timezone_set('Asia/Kolkata');

// ============ IP DETECTION ============
function al_get_user_ip() {
    $ip_keys = [
        'REMOTE_ADDR',
        'HTTP_CLIENT_IP',
        'HTTP_X_REAL_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
    ];
    
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) && !empty($_SERVER[$key])) {
            $ips = explode(',', $_SERVER[$key]);
            
            foreach ($ips as $ip) {
                $ip = trim($ip);
                
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    $clean_ip = str_replace(['(Office)', '(Home)'], '', $ip);
                    $clean_ip = trim($clean_ip);
                    
                    $office_ips = AL_OFFICE_IPS;
                    if (in_array($clean_ip, $office_ips) || in_array($ip, $office_ips)) {
                        return "$clean_ip (Office)";
                    }
                    
                    return "$ip (Home)";
                }
            }
        }
    }
    
    return 'UNKNOWN';
}

function al_get_all_ip_headers() {
    $ip_info = [];
    $headers = [
        'REMOTE_ADDR', 'HTTP_CLIENT_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR',
        'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'SERVER_ADDR', 'LOCAL_ADDR'
    ];
    
    foreach ($headers as $header) {
        if (isset($_SERVER[$header]) && !empty($_SERVER[$header])) {
            $ip_info[$header] = $_SERVER[$header];
        }
    }
    
    return $ip_info;
}

function al_log_ip_debug_info() {
    if (current_user_can('manage_options') && isset($_GET['debug_ip'])) {
        echo '<div class="notice notice-info" style="padding: 15px;"><h3>🔍 IP Debug Information:</h3>';
        echo '<p><strong>Detected IP:</strong> <span style="color: green; font-size: 16px;">' . al_get_user_ip() . '</span></p>';
        echo '<hr><h4>All Available IP Headers:</h4><pre style="background: #f5f5f5; padding: 10px; border-radius: 5px;">';
        
        $all_ips = al_get_all_ip_headers();
        if (empty($all_ips)) {
            echo "No IP headers found!";
        } else {
            foreach ($all_ips as $header => $value) {
                echo "<strong>$header:</strong> $value\n";
            }
        }
        
        echo '</pre>';
        echo '<p><strong>Office IPs in Config:</strong> ' . implode(', ', AL_OFFICE_IPS) . '</p>';
        echo '</div>';
    }
}
add_action('admin_notices', 'al_log_ip_debug_info');

// ============ CORE LOGGING FUNCTIONS ============
function al_log_activity($user_id, $username, $action) {
    if (!file_exists(AL_LOG_FILE)) {
        $file = fopen(AL_LOG_FILE, 'w');
        fputcsv($file, ['User ID', 'Username', 'Action', 'IP Address', 'Timestamp']);
        fclose($file);
    }
    
    $file = fopen(AL_LOG_FILE, 'a');
    fputcsv($file, [$user_id, $username, $action, al_get_user_ip(), date('Y-m-d H:i:s')]);
    fclose($file);
}

function al_send_security_email($alert_name, $username, $action) {
    $subject = "!! Security Alert !! - " . get_bloginfo('name');
    $message = "Alert Type: $alert_name\n";
    $message .= "User: $username\n";
    $message .= "IP Address: " . al_get_user_ip() . "\n";
    $message .= "Time: " . date('Y-m-d H:i:s') . "\n";
    $message .= "Action: $action\n";
    $message .= "Website: " . get_bloginfo('name') . "\n";
    $message .= "URL: " . get_bloginfo('url');
    
    wp_mail(AL_ADMIN_EMAIL, $subject, $message);
}

function al_track_activity($action) {
    $user = wp_get_current_user();
    al_log_activity($user->ID, $user->user_login, $action);
    return [$user->ID, $user->user_login, $action];
}

function al_track_and_alert($action) {
    $data = al_track_activity($action);
    al_send_security_email(trim(explode(':', $action)[0]), $data[1], $action);
}

function al_add_hooks($hooks) {
    foreach ($hooks as $hook => $callback) {
        $params = isset($callback['params']) ? $callback['params'] : 1;
        add_action($hook, $callback['fn'], 10, $params);
    }
}

// ============ USER ACTION HOOKS ============
al_add_hooks([
    'user_register' => [
        'fn' => function($user_id) {
            $user = get_userdata($user_id);
            al_log_activity($user_id, $user->user_login, 'User Created');
            al_send_security_email("User Created", $user->user_login, 'User Created');
        }
    ],
    'delete_user' => [
        'fn' => function($user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                al_log_activity($user_id, $user->user_login, 'User Deleted');
                al_send_security_email("User Deleted", $user->user_login, 'User Deleted');
            }
        }
    ],
    'wp_login' => [
        'fn' => function($user_login, $user) {
            // Only log if not 2FA (2FA logs separately)
            if (!al_is_2fa_enabled_for_user($user->ID)) {
                al_log_activity($user->ID, $user_login, 'Logged In');
                al_send_security_email("Successful Login Alert", $user_login, 'Logged In');
            }
            al_log_ip_access($user_login);
        },
        'params' => 2
    ],
    'clear_auth_cookie' => [
        'fn' => function() {
            $user = wp_get_current_user();
            if ($user->ID) {
                al_log_activity($user->ID, $user->user_login, 'Logged Out');
                al_send_security_email("Logout Alert", $user->user_login, 'Logged Out');
            }
        }
    ],
    'wp_login_failed' => [
        'fn' => function($username) {
            al_log_activity(0, $username, 'Security Alert: Failed Login Attempt');
            al_send_security_email("Failed Login Attempt", $username, 'Failed Login Attempt');
            al_log_ip_access($username, 'failed');
        }
    ],
    'set_user_role' => [
        'fn' => function($user_id, $role, $old_roles) {
            $user = get_userdata($user_id);
            if ($user) {
                $action = 'Role Changed: ' . implode(', ', $old_roles) . ' → ' . $role;
                al_log_activity($user_id, $user->user_login, $action);
                al_send_security_email("User Role Changed", $user->user_login, $action);
            }
        },
        'params' => 3
    ]
]);

// ============ 2FA FUNCTIONS - COMPLETELY FIXED ============

function al_is_2fa_enabled_for_user($user_id) {
    return get_user_meta($user_id, 'al_enable_2fa', true) === '1';
}

function al_generate_2fa_code($user_id) {
    $code = sprintf("%06d", mt_rand(100000, 999999));
    set_transient('al_2fa_code_' . $user_id, $code, 600); // 10 minutes
    return $code;
}

function al_send_2fa_code($user_id, $code) {
    $user = get_userdata($user_id);
    if (!$user) return false;
    
    $to = $user->user_email;
    $subject = '🔐 Your Login Code - ' . get_bloginfo('name');
    
    $message = "Hello {$user->display_name},\n\n";
    $message .= "Your two-factor authentication code is:\n\n";
    $message .= "CODE: {$code}\n\n";
    $message .= "This code will expire in 10 minutes.\n";
    $message .= "If you didn't request this, please ignore this email.\n\n";
    $message .= "Time: " . date('Y-m-d H:i:s') . "\n";
    $message .= "IP: " . al_get_user_ip() . "\n";
    $message .= "Website: " . get_bloginfo('name');
    
    $sent = wp_mail($to, $subject, $message);
    
    if ($sent) {
        al_log_activity($user_id, $user->user_login, '2FA Code Sent via Email');
    } else {
        al_log_activity($user_id, $user->user_login, '2FA Code Email Failed');
    }
    
    return $sent;
}

// STEP 1: Intercept login and send OTP
add_filter('authenticate', 'al_intercept_login_for_2fa', 30, 3);
function al_intercept_login_for_2fa($user, $username, $password) {
    // Skip if already handling 2FA verification
    if (isset($_POST['al_verify_2fa_code'])) {
        return $user;
    }
    
    // Skip if not a valid user
    if (!is_a($user, 'WP_User')) {
        return $user;
    }
    
    // Check if 2FA is enabled for this user
    if (!al_is_2fa_enabled_for_user($user->ID)) {
        return $user;
    }
    
    // Generate and send OTP
    $code = al_generate_2fa_code($user->ID);
    al_send_2fa_code($user->ID, $code);
    
    // Store user data in transient (more reliable than session)
    set_transient('al_2fa_pending_user_' . $user->ID, [
        'user_id' => $user->ID,
        'username' => $username,
        'password' => $password, // Store password for re-authentication
        'time' => time()
    ], 600);
    
    // Redirect to 2FA page
    wp_safe_redirect(wp_login_url() . '?al_2fa_required=' . $user->ID);
    exit;
}

// STEP 2: Show 2FA input form
add_action('login_form', 'al_show_2fa_verification_form');
function al_show_2fa_verification_form() {
    if (!isset($_GET['al_2fa_required'])) {
        return;
    }
    
    $user_id = intval($_GET['al_2fa_required']);
    $pending_data = get_transient('al_2fa_pending_user_' . $user_id);
    
    if (!$pending_data) {
        echo '<div class="message" style="background:#ffeaa7; border:1px solid #fdcb6e; padding:10px; margin:10px 0;">';
        echo '<strong>Session Expired:</strong> Please login again.';
        echo '</div>';
        return;
    }
    
    $user = get_userdata($user_id);
    if (!$user) return;
    
    // Hide default login form
    ?>
    <style>
        #loginform > p:not(.al-2fa-field),
        #loginform > p.forgetmenot,
        #nav,
        #backtoblog {
            display: none !important;
        }
    </style>
    
    <div class="al-2fa-container" style="background:#f9f9f9; border:1px solid #ccd0d4; padding:20px; margin:20px 0; border-radius:5px;">
        <h3 style="margin-top:0; color:#23282d;">🔐 Two-Factor Authentication</h3>
        <p>Hello <strong><?php echo esc_html($user->display_name); ?></strong>,</p>
        <p>We've sent a 6-digit code to: <strong><?php echo esc_html($user->user_email); ?></strong></p>
        
        <?php
        // Show error message
        if (isset($_GET['al_2fa_error'])) {
            echo '<div style="background:#ffeaa7; border:1px solid #fdcb6e; padding:10px; margin:10px 0; border-radius:3px;">';
            echo '<strong>❌ Invalid Code:</strong> Please check and try again.';
            echo '</div>';
        }
        
        // Show resend confirmation
        if (isset($_GET['al_2fa_resent'])) {
            echo '<div style="background:#d1ecf1; border:1px solid #bee5eb; padding:10px; margin:10px 0; border-radius:3px;">';
            echo '<strong>✅ New Code Sent:</strong> Check your email for the new code.';
            echo '</div>';
        }
        ?>
        
        <p class="al-2fa-field">
            <label for="al_2fa_code" style="display:block; margin-bottom:5px;"><strong>Enter 6-Digit Code:</strong></label>
            <input type="text" 
                   name="al_2fa_code" 
                   id="al_2fa_code" 
                   class="input" 
                   size="20" 
                   maxlength="6" 
                   pattern="[0-9]{6}" 
                   required
                   autocomplete="off"
                   autofocus
                   placeholder="000000"
                   style="font-size:24px; padding:10px; text-align:center; letter-spacing:8px; width:100%;">
        </p>
        
        <p class="al-2fa-field submit">
            <input type="submit" 
                   name="wp-submit" 
                   id="wp-submit" 
                   class="button button-primary button-large" 
                   value="✅ Verify & Login"
                   style="width:100%; height:45px; font-size:16px;">
            <input type="hidden" name="al_verify_2fa_code" value="1">
            <input type="hidden" name="al_user_id" value="<?php echo esc_attr($user_id); ?>">
        </p>
    </div>
    
    <div style="text-align:center; margin:15px 0; padding:15px 0; border-top:1px solid #ddd;">
        <p style="font-size:13px; color:#666;">
            Didn't receive the code?
            <a href="<?php echo wp_login_url(); ?>?al_2fa_resend=<?php echo $user_id; ?>" 
               style="color:#0073aa; text-decoration:none; font-weight:bold;">
                📧 Resend Code
            </a>
        </p>
        <p style="font-size:12px; color:#999;">Code expires in 10 minutes</p>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Hide default form elements
        $('#loginform > p:not(.al-2fa-field)').hide();
        $('#nav, #backtoblog').hide();
        
        // Focus on code input
        $('#al_2fa_code').focus();
        
        // Auto-submit when 6 digits entered
        $('#al_2fa_code').on('input', function() {
            // Only allow numbers
            this.value = this.value.replace(/[^0-9]/g, '');
            
            // Auto-submit when 6 digits
            if (this.value.length === 6) {
                $('#loginform').submit();
            }
        });
    });
    </script>
    <?php
}

// STEP 3: Handle resend OTP request
add_action('login_init', 'al_handle_2fa_resend');
function al_handle_2fa_resend() {
    if (!isset($_GET['al_2fa_resend'])) {
        return;
    }
    
    $user_id = intval($_GET['al_2fa_resend']);
    $pending_data = get_transient('al_2fa_pending_user_' . $user_id);
    
    if ($pending_data) {
        // Generate new code
        $code = al_generate_2fa_code($user_id);
        al_send_2fa_code($user_id, $code);
        
        // Redirect back with success message
        wp_safe_redirect(wp_login_url() . '?al_2fa_required=' . $user_id . '&al_2fa_resent=1');
        exit;
    }
}

// STEP 4: Verify OTP and complete login - FIXED VERSION
add_filter('authenticate', 'al_verify_2fa_and_login', 40, 3);
function al_verify_2fa_and_login($user, $username, $password) {
    // Only process if it's a 2FA verification request
    if (!isset($_POST['al_verify_2fa_code']) || !isset($_POST['al_user_id'])) {
        return $user;
    }
    
    $user_id = intval($_POST['al_user_id']);
    $entered_code = sanitize_text_field($_POST['al_2fa_code']);
    
    // Get stored code and pending user data
    $stored_code = get_transient('al_2fa_code_' . $user_id);
    $pending_data = get_transient('al_2fa_pending_user_' . $user_id);
    
    if (!$pending_data) {
        return new WP_Error('2fa_expired', '<strong>ERROR:</strong> Session expired. Please login again.');
    }
    
    // Verify code
    if ($stored_code && $stored_code === $entered_code) {
        // Code is correct! Now authenticate the user properly
        delete_transient('al_2fa_code_' . $user_id);
        delete_transient('al_2fa_pending_user_' . $user_id);
        
        // Get the user by ID
        $user = get_user_by('id', $user_id);
        
        if (!$user) {
            return new WP_Error('2fa_invalid_user', '<strong>ERROR:</strong> Invalid user.');
        }
        
        // Log successful 2FA verification
        al_log_activity($user_id, $user->user_login, '2FA Verified - Login Successful');
        
        // Set the authentication cookie manually
        wp_clear_auth_cookie();
        wp_set_current_user($user_id, $user->user_login);
        wp_set_auth_cookie($user_id, true);
        
        // Update user activity
        update_user_caches($user);
        
        // Log IP access
        al_log_ip_access($user->user_login);
        
        // Send security email
        al_send_security_email("2FA Login Successful", $user->user_login, 'Logged In with 2FA');
        
        // Redirect to admin dashboard
        wp_safe_redirect(admin_url());
        exit;
        
    } else {
        // Wrong code
        al_log_activity($user_id, $pending_data['username'], '2FA Failed: Invalid Code');
        
        // Redirect back with error
        wp_safe_redirect(wp_login_url() . '?al_2fa_required=' . $user_id . '&al_2fa_error=1');
        exit;
    }
    
    return $user;
}

// Log IP access
function al_log_ip_access($username, $status = 'success') {
    $ip = al_get_user_ip();
    $timestamp = time();
    
    if (!file_exists(AL_IP_LOG_FILE)) {
        $file = fopen(AL_IP_LOG_FILE, 'w');
        fputcsv($file, ['IP', 'Username', 'Status', 'Timestamp']);
        fclose($file);
    }
    
    $file = fopen(AL_IP_LOG_FILE, 'a');
    fputcsv($file, [$ip, $username, $status, $timestamp]);
    fclose($file);
}

// ============ CONTENT CHANGE TRACKING ============
function al_track_page_post_changes($post_ID, $post_after, $post_before) {
    if (wp_is_post_revision($post_ID) || wp_is_post_autosave($post_ID)) return;
    
    $post_type = get_post_type($post_ID);
    $title = $post_after->post_title;
    $action = '';
    
    if ($post_before->post_status === 'auto-draft' && $post_after->post_status === 'publish')
        $action = ucfirst($post_type) . ' Created: ' . $title;
    elseif ($post_before->post_status !== 'trash' && $post_after->post_status === 'trash')
        $action = ucfirst($post_type) . ' Trashed: ' . $title;
    elseif ($post_before->post_status === 'trash' && $post_after->post_status === 'publish')
        $action = ucfirst($post_type) . ' Restored: ' . $title;
    elseif (($post_before->post_content !== $post_after->post_content ||
            $post_before->post_title !== $post_after->post_title ||
            $post_before->post_excerpt !== $post_after->post_excerpt) &&
            $post_before->post_status === 'publish' && $post_after->post_status === 'publish')
        $action = ucfirst($post_type) . ' Modified: ' . $title;
    
    if (!empty($action)) {
        $user = wp_get_current_user();
        al_log_activity($user->ID, $user->user_login, $action);
    }
}
add_action('post_updated', 'al_track_page_post_changes', 10, 3);

add_action('before_delete_post', function($post_id) {
    $post = get_post($post_id);
    if ($post && $post->post_status !== 'trash') {
        al_track_activity(ucfirst($post->post_type) . ' Deleted: ' . $post->post_title);
    }
});

// ============ THEME AND PLUGIN CHANGES ============
add_action('after_switch_theme', function() {
    al_track_and_alert('Theme Changed to: ' . wp_get_theme()->get('Name'));
});

al_add_hooks([
    'upgrader_process_complete' => [
        'fn' => function($upgrader_object, $options) {
            if ($options['type'] == 'plugin') {
                if ($options['action'] == 'install') {
                    if (isset($upgrader_object->new_plugin_data)) {
                        $plugin_name = $upgrader_object->new_plugin_data['Name'] ?? 'Unknown Plugin';
                        al_track_and_alert('Plugin Installed: ' . $plugin_name);
                    } elseif (!empty($options['plugins'])) {
                        foreach ($options['plugins'] as $plugin) {
                            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
                            $plugin_name = $plugin_data['Name'] ?? $plugin;
                            al_track_and_alert('Plugin Installed: ' . $plugin_name);
                        }
                    }
                }
                
                if ($options['action'] == 'update') {
                    if (!empty($options['plugins'])) {
                        foreach ($options['plugins'] as $plugin) {
                            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
                            $plugin_name = $plugin_data['Name'] ?? $plugin;
                            al_track_activity('Plugin Updated: ' . $plugin_name);
                        }
                    }
                }
            }
        },
        'params' => 2
    ],
    'activated_plugin' => [
        'fn' => function($plugin, $network_wide) {
            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
            $plugin_name = $plugin_data['Name'] ?? $plugin;
            al_track_and_alert('Plugin Activated: ' . $plugin_name);
        },
        'params' => 2
    ],
    'deactivated_plugin' => [
        'fn' => function($plugin, $network_wide) {
            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
            $plugin_name = $plugin_data['Name'] ?? $plugin;
            al_track_and_alert('Plugin Deactivated: ' . $plugin_name);
        },
        'params' => 2
    ],
    'deleted_plugin' => [
        'fn' => function($plugin_file, $deleted) {
            if ($deleted) {
                $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file, false, false);
                $plugin_name = $plugin_data['Name'] ?? $plugin_file;
                al_track_and_alert('Plugin Deleted: ' . $plugin_name);
            }
        },
        'params' => 2
    ]
]);

// ============ OPTIONS AND META CHANGES ============
al_add_hooks([
    'added_option' => ['fn' => function($option) { 
        if (strpos($option, '_transient') !== 0) al_track_activity("Option Added: $option"); 
    }],
    'updated_option' => ['fn' => function($option) { 
        if (strpos($option, '_transient') !== 0) al_track_activity("Option Updated: $option"); 
    }],
    'deleted_option' => ['fn' => function($option) { 
        if (strpos($option, '_transient') !== 0) al_track_activity("Option Deleted: $option"); 
    }],
    'added_post_meta' => [
        'fn' => function($meta_id, $post_id, $meta_key) { 
            if (strpos($meta_key, '_') !== 0) al_track_activity("Meta Added to Post ID $post_id: $meta_key"); 
        },
        'params' => 3
    ],
    'updated_post_meta' => [
        'fn' => function($meta_id, $post_id, $meta_key) { 
            if (strpos($meta_key, '_') !== 0) al_track_activity("Meta Updated in Post ID $post_id: $meta_key"); 
        },
        'params' => 3
    ],
    'deleted_post_meta' => [
        'fn' => function($meta_ids, $post_id, $meta_key) { 
            if (strpos($meta_key, '_') !== 0) al_track_activity("Meta Deleted from Post ID $post_id: $meta_key"); 
        },
        'params' => 3
    ],
    'wp_insert_comment' => [
        'fn' => function($comment_id) { al_track_activity("New Comment Added: ID $comment_id"); },
        'params' => 1
    ]
]);

// ============ NEW FEATURES ============

// Custom Login URL Functions
function al_get_custom_login_url() {
    return get_option('al_custom_login_slug', '');
}

function al_is_custom_login_enabled() {
    return !empty(al_get_custom_login_url());
}

// File Editing Control
function al_is_file_editing_disabled() {
    return get_option('al_disable_file_editing', false);
}

if (al_is_file_editing_disabled() && !defined('DISALLOW_FILE_EDIT')) {
    define('DISALLOW_FILE_EDIT', true);
    define('DISALLOW_FILE_MODS', true);
}

// File Protection Functions
function al_get_protected_files() {
    return get_option('al_protected_files', ['wp-config.php', '.htaccess', 'readme.html', 'license.txt']);
}

function al_is_file_protection_enabled() {
    return get_option('al_enable_file_protection', false);
}

// reCAPTCHA Functions
function al_is_recaptcha_enabled() {
    return get_option('al_enable_recaptcha', false) && 
           !empty(get_option('al_recaptcha_site_key')) && 
           !empty(get_option('al_recaptcha_secret_key'));
}

function al_verify_recaptcha($response) {
    $secret_key = get_option('al_recaptcha_secret_key');
    
    $verify_url = 'https://www.google.com/recaptcha/api/siteverify';
    $http_response = wp_remote_post($verify_url, [
        'body' => [
            'secret' => $secret_key,
            'response' => $response
        ]
    ]);
    
    if (is_wp_error($http_response)) return false;
    
    $body = json_decode(wp_remote_retrieve_body($http_response), true);
    return isset($body['success']) && $body['success'] === true;
}

// SMTP Status
function al_check_smtp_status() {
    $smtp_status = [];
    
    if (defined('SMTP_HOST') && defined('SMTP_PORT')) {
        $smtp_status['configured'] = true;
        $smtp_status['host'] = SMTP_HOST;
        $smtp_status['port'] = SMTP_PORT;
    } else {
        $smtp_status['configured'] = false;
    }
    
    $test_result = @wp_mail(AL_ADMIN_EMAIL, 'SMTP Test', 'This is a test email');
    $smtp_status['working'] = $test_result !== false;
    
    return $smtp_status;
}

// Contact Form Database Storage
function al_save_contact_form_to_database($form_id, $form_title, $name, $email, $phone, $message) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'al_contact_form_entries';
    
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        form_id varchar(50) NOT NULL,
        form_title varchar(255) NOT NULL,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(50) DEFAULT NULL,
        message text NOT NULL,
        ip_address varchar(100) NOT NULL,
        submitted_at datetime NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    $wpdb->insert(
        $table_name,
        [
            'form_id' => $form_id,
            'form_title' => $form_title,
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'message' => $message,
            'ip_address' => al_get_user_ip(),
            'submitted_at' => current_time('mysql')
        ]
    );
}

// ============ IP ACCESS & BLOCKING ============
function al_check_for_unusual_traffic($current_ip, $username) {
    if (!file_exists(AL_IP_LOG_FILE)) return;
    
    $file = fopen(AL_IP_LOG_FILE, 'r');
    $header = fgetcsv($file);
    
    $ip_counts = [];
    $failed_attempts = [];
    $current_time = time();
    
    while (($data = fgetcsv($file)) !== false) {
        if (count($data) < 4) continue;
        
        list($ip, $user, $status, $timestamp) = $data;
        
        if ($current_time - $timestamp <= AL_TIME_WINDOW) {
            if (!isset($ip_counts[$ip])) $ip_counts[$ip] = 0;
            $ip_counts[$ip]++;
            
            if ($status === 'failed') {
                if (!isset($failed_attempts[$ip])) $failed_attempts[$ip] = 0;
                $failed_attempts[$ip]++;
            }
        }
    }
    fclose($file);
    
    if (isset($ip_counts[$current_ip]) && $ip_counts[$current_ip] > 20) {
        $action = "Unusual Traffic Alert: High access frequency from IP $current_ip ({$ip_counts[$current_ip]} requests in " . (AL_TIME_WINDOW/60) . " minutes)";
        al_track_and_alert($action);
    }
    
    if (isset($failed_attempts[$current_ip]) && $failed_attempts[$current_ip] >= AL_MAX_LOGIN_ATTEMPTS) {
        al_block_ip($current_ip, $username, $failed_attempts[$current_ip]);
        $action = "IP Blocked Alert: IP $current_ip blocked after {$failed_attempts[$current_ip]} failed login attempts";
        al_track_and_alert($action);
    }
    
    if (strpos($current_ip, 'Office') === false && !in_array($current_ip, get_option('al_known_ips', []))) {
        $known_ips = get_option('al_known_ips', []);
        $known_ips[] = $current_ip;
        update_option('al_known_ips', array_unique($known_ips));
        
        $action = "New IP Access Alert: First time access from IP $current_ip";
        al_track_and_alert($action);
    }
}

function al_block_ip($ip, $username, $attempt_count) {
    if (!file_exists(AL_BLOCKED_IPS_FILE)) {
        $file = fopen(AL_BLOCKED_IPS_FILE, 'w');
        fputcsv($file, ['IP', 'Username', 'Attempts', 'Blocked Time', 'Reason']);
        fclose($file);
    }
    
    $file = fopen(AL_BLOCKED_IPS_FILE, 'a');
    fputcsv($file, [$ip, $username, $attempt_count, date('Y-m-d H:i:s'), 'Multiple failed login attempts']);
    fclose($file);
}

function al_is_ip_blocked($ip) {
    if (!file_exists(AL_BLOCKED_IPS_FILE)) return false;
    
    $clean_ip = str_replace(['(Office)', '(Home)'], '', $ip);
    $clean_ip = trim($clean_ip);
    
    $file = fopen(AL_BLOCKED_IPS_FILE, 'r');
    $header = fgetcsv($file);
    
    while (($data = fgetcsv($file)) !== false) {
        $blocked_ip = str_replace(['(Office)', '(Home)'], '', $data[0]);
        $blocked_ip = trim($blocked_ip);
        
        if ($blocked_ip === $clean_ip) {
            fclose($file);
            return true;
        }
    }
    fclose($file);
    return false;
}

function al_unblock_ip($ip_to_unblock) {
    if (!file_exists(AL_BLOCKED_IPS_FILE)) return false;
    
    $temp_file = AL_BLOCKED_IPS_FILE . '.tmp';
    $file = fopen(AL_BLOCKED_IPS_FILE, 'r');
    $temp = fopen($temp_file, 'w');
    
    $header = fgetcsv($file);
    fputcsv($temp, $header);
    
    $found = false;
    while (($data = fgetcsv($file)) !== false) {
        if ($data[0] !== $ip_to_unblock) {
            fputcsv($temp, $data);
        } else {
            $found = true;
        }
    }
    
    fclose($file);
    fclose($temp);
    
    if ($found) {
        unlink(AL_BLOCKED_IPS_FILE);
        rename($temp_file, AL_BLOCKED_IPS_FILE);
        al_track_activity("IP Unblocked: $ip_to_unblock");
        return true;
    } else {
        unlink($temp_file);
        return false;
    }
}

add_action('init', function() {
    if (is_admin()) return;
    
    $current_ip = al_get_user_ip();
    if (al_is_ip_blocked($current_ip)) {
        wp_die('Your IP address has been blocked due to suspicious activity. Please contact the administrator at ' . AL_ADMIN_EMAIL);
    }
});

// ============ SECURITY MONITORING ============
function al_check_security_changes() {
    al_log_activity(0, 'System', 'Security Scan Started');
    
    al_check_ssl_status();
    al_check_file_permissions();
    al_check_security_plugins();
    al_check_firewall_status();
    
    al_log_activity(0, 'System', 'Security Scan Completed');
    
    if (!wp_next_scheduled('al_security_scan_hook')) {
        wp_schedule_event(time(), 'daily', 'al_security_scan_hook');
    }
    
    return true;
}

function al_check_ssl_status() {
    $is_ssl = is_ssl();
    $force_ssl_admin = defined('FORCE_SSL_ADMIN') && FORCE_SSL_ADMIN;
    $was_ssl = get_option('al_site_was_ssl', null);
    
    if ($was_ssl === null) {
        update_option('al_site_was_ssl', $is_ssl);
        al_log_activity(0, 'System', 'SSL Status Initialized: ' . ($is_ssl ? 'Enabled' : 'Disabled'));
    } else if ($was_ssl && !$is_ssl) {
        al_track_and_alert("Security Alert: SSL has been disabled for the site");
    } else if (!$was_ssl && $is_ssl) {
        al_track_activity("Security Update: SSL has been enabled for the site");
    }
    
    $was_ssl_admin = get_option('al_ssl_admin_was_forced', null);
    if ($was_ssl_admin === null) {
        update_option('al_ssl_admin_was_forced', $force_ssl_admin);
    } else if ($was_ssl_admin && !$force_ssl_admin) {
        al_track_and_alert("Security Alert: Forced SSL for admin has been disabled");
    }
    
    update_option('al_site_was_ssl', $is_ssl);
    update_option('al_ssl_admin_was_forced', $force_ssl_admin);
}

function al_check_file_permissions() {
    $wp_config_path = ABSPATH . 'wp-config.php';
    
    if (file_exists($wp_config_path)) {
        $perms = substr(sprintf('%o', fileperms($wp_config_path)), -4);
        $prev_perms = get_option('al_wp_config_permissions', '');
        
        if (empty($prev_perms)) {
            update_option('al_wp_config_permissions', $perms);
            al_log_activity(0, 'System', 'wp-config.php permissions initialized: ' . $perms);
        } else if ($prev_perms !== $perms) {
            al_track_and_alert("Security Alert: wp-config.php permissions changed from $prev_perms to $perms");
            update_option('al_wp_config_permissions', $perms);
        }
        
        if ($perms[3] > 0) {
            al_track_and_alert("Security Alert: wp-config.php has unsafe permissions ($perms)");
        }
    }
}

function al_check_security_plugins() {
    $security_plugins = [
        'wordfence/wordfence.php' => 'Wordfence',
        'sucuri-scanner/sucuri.php' => 'Sucuri',
        'better-wp-security/better-wp-security.php' => 'iThemes Security',
        'all-in-one-wp-security-and-firewall/wp-security.php' => 'All In One WP Security'
    ];
    
    $active_plugins = get_option('active_plugins', []);
    $active_security_plugins = array_intersect(array_keys($security_plugins), $active_plugins);
    
    $prev_active_security = get_option('al_active_security_plugins', []);
    
    if (empty($prev_active_security)) {
        update_option('al_active_security_plugins', $active_security_plugins);
    } else {
        $deactivated = array_diff($prev_active_security, $active_security_plugins);
        
        foreach ($deactivated as $plugin) {
            $plugin_name = isset($security_plugins[$plugin]) ? $security_plugins[$plugin] : basename($plugin);
            al_track_and_alert("Security Alert: Security plugin deactivated: $plugin_name");
        }
        
        update_option('al_active_security_plugins', $active_security_plugins);
    }
}

function al_check_firewall_status() {
    $firewall_status = al_get_firewall_status();
    $prev_status = get_option('al_firewall_previous_status', null);
    
    if ($prev_status === null) {
        update_option('al_firewall_previous_status', $firewall_status);
    } else if ($prev_status !== $firewall_status) {
        $status_text = $firewall_status ? 'enabled' : 'disabled';
        al_track_and_alert("Security Alert: Firewall has been $status_text");
        update_option('al_firewall_previous_status', $firewall_status);
    }
}

function al_get_firewall_status() {
    if (function_exists('wfConfig') && class_exists('wfConfig')) {
        try {
            return wfConfig::get('firewallEnabled', false);
        } catch (Exception $e) {}
    }
    
    if (function_exists('itsec_get_settings')) {
        try {
            $settings = itsec_get_settings();
            return isset($settings['active']) && $settings['active'];
        } catch (Exception $e) {}
    }
    
    if (class_exists('AIO_WP_Security')) {
        try {
            global $aio_wp_security;
            if (isset($aio_wp_security->configs)) {
                return $aio_wp_security->configs->get_value('aiowps_enable_basic_firewall') == '1';
            }
        } catch (Exception $e) {}
    }
    
    $htaccess_path = ABSPATH . '.htaccess';
    if (file_exists($htaccess_path)) {
        $htaccess_content = file_get_contents($htaccess_path);
        if (strpos($htaccess_content, 'RewriteEngine On') !== false || 
            strpos($htaccess_content, 'deny from') !== false) {
            return true;
        }
    }
    
    return false;
}

function al_get_outdated_plugins() {
    if (!function_exists('get_plugin_updates')) {
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    wp_update_plugins();
    return get_plugin_updates();
}

// ============ CONTACT FORM INTEGRATION ============
add_action('wpcf7_before_send_mail', function($contact_form) {
    if (!class_exists('WPCF7_Submission')) return;
    
    $submission = WPCF7_Submission::get_instance();
    if (!$submission) return;
    
    $posted_data = $submission->get_posted_data();
    
    if (!file_exists(AL_CONTACT_FORM_LOG_FILE)) {
        $file = fopen(AL_CONTACT_FORM_LOG_FILE, 'w');
        fputcsv($file, ['Form ID', 'Form Title', 'Name', 'Email', 'Phone', 'Message', 'IP Address', 'Timestamp']);
        fclose($file);
    }
    
    $name = isset($posted_data['your-name']) ? sanitize_text_field($posted_data['your-name']) : 
            (isset($posted_data['name']) ? sanitize_text_field($posted_data['name']) : 'N/A');
    
    $email = isset($posted_data['your-email']) ? sanitize_email($posted_data['your-email']) : 
             (isset($posted_data['email']) ? sanitize_email($posted_data['email']) : 'N/A');
    
    $phone = isset($posted_data['your-phone']) ? sanitize_text_field($posted_data['your-phone']) : 
             (isset($posted_data['phone']) ? sanitize_text_field($posted_data['phone']) : 'N/A');
    
    $message = isset($posted_data['your-message']) ? sanitize_textarea_field($posted_data['your-message']) : 
               (isset($posted_data['message']) ? sanitize_textarea_field($posted_data['message']) : 'N/A');
    
    $file = fopen(AL_CONTACT_FORM_LOG_FILE, 'a');
    fputcsv($file, [
        $contact_form->id(),
        $contact_form->title(),
        $name,
        $email,
        $phone,
        $message,
        al_get_user_ip(),
        date('Y-m-d H:i:s')
    ]);
    fclose($file);
    
    al_save_contact_form_to_database($contact_form->id(), $contact_form->title(), $name, $email, $phone, $message);
});

// ============ ADMIN MENU ============
add_action('admin_menu', function() {
    add_menu_page('Activity Logs', 'Activity Logs', 'manage_options', 'al-activity-logs', 'al_display_activity_logs', 'dashicons-visibility', 20);
    add_submenu_page('al-activity-logs', 'Security Monitor', 'Security Monitor', 'manage_options', 'al-security-monitor', 'al_display_security_monitor');
    add_submenu_page('al-activity-logs', 'IP Access Logs', 'IP Access Logs', 'manage_options', 'al-ip-access-logs', 'al_display_ip_access_logs');
    add_submenu_page('al-activity-logs', 'Blocked IPs', 'Blocked IPs', 'manage_options', 'al-blocked-ips', 'al_display_blocked_ips');
    add_submenu_page('al-activity-logs', 'Outdated Plugins', 'Outdated Plugins', 'manage_options', 'al-outdated-plugins', 'al_display_outdated_plugins');
    add_submenu_page('al-activity-logs', 'Contact Forms', 'Contact Forms', 'manage_options', 'al-contact-forms', 'al_display_contact_form_logs');
    add_submenu_page('al-activity-logs', 'Security Settings', 'Security Settings', 'manage_options', 'al-security-settings', 'al_display_security_settings');
    add_submenu_page('al-activity-logs', '2FA Settings', '2FA Settings', 'manage_options', 'al-2fa-settings', 'al_display_2fa_settings');
});

// ============ DISPLAY FUNCTIONS ============
function al_display_activity_logs() {
    $categories = ['All', 'User Created', 'User Deleted', 'Role Changed', 'Logged In', 'Logged Out', 
                  'Security Alert', 'Page Created', 'Page Modified', 'Page Deleted', 'Post Created', 
                  'Post Modified', 'Post Deleted', 'Theme Changed', 'Plugin'];
    $selected = isset($_GET['log_filter']) ? sanitize_text_field($_GET['log_filter']) : 'All';
    
    echo "<div class='wrap'><h1>Activity Logs</h1>";
    
    $current_ip = al_get_user_ip();
    $ip_style = strpos($current_ip, 'Office') !== false ? 'color: green;' : 'color: blue;';
    echo "<div class='notice notice-info' style='padding: 15px;'>";
    echo "<p style='margin: 0;'><strong>🌐 Your Current IP:</strong> ";
    echo "<span style='$ip_style font-size: 16px; font-weight: bold;'>$current_ip</span></p>";
    echo "</div>";
    
    echo "<form method='GET' style='margin: 15px 0;'><input type='hidden' name='page' value='al-activity-logs'>";
    echo "<select name='log_filter' onchange='this.form.submit()' style='padding: 5px;'>";
    
    foreach ($categories as $category) {
        echo "<option value='$category' " . ($selected == $category ? 'selected' : '') . ">$category</option>";
    }
    
    echo "</select></form><table class='widefat fixed striped'><thead><tr>
          <th width='5%'>#</th><th width='8%'>User ID</th><th width='15%'>User</th><th width='35%'>Action</th>
          <th width='17%'>IP Address</th><th width='20%'>Timestamp</th></tr></thead><tbody>";
    
    if (file_exists(AL_LOG_FILE) && ($handle = fopen(AL_LOG_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $rows = [];
        while (($data = fgetcsv($handle)) !== false) {
            if ($selected == 'All' || strpos($data[2], $selected) !== false) {
                $rows[] = $data;
            }
        }
        fclose($handle);
        
        $count = count($rows);
        foreach (array_reverse($rows) as $log) {
            $ip_highlight = strpos($log[3], 'Office') !== false ? 'style="color: green; font-weight: bold;"' : '';
            echo "<tr><td>{$count}</td><td>{$log[0]}</td><td>{$log[1]}</td>
                 <td>{$log[2]}</td><td $ip_highlight>{$log[3]}</td><td>{$log[4]}</td></tr>";
            $count--;
        }
    }
    echo "</tbody></table></div>";
}

function al_display_ip_access_logs() {
    echo "<div class='wrap'><h1>IP Access Logs</h1>";
    
    $current_ip = al_get_user_ip();
    $ip_style = strpos($current_ip, 'Office') !== false ? 'color: green;' : 'color: blue;';
    
    echo "<div class='notice notice-info' style='padding: 15px;'>";
    echo "<p style='margin: 0;'><strong>🌐 Current IP:</strong> ";
    echo "<span style='$ip_style font-size: 16px; font-weight: bold;'>$current_ip</span></p>";
    echo "</div>";
    
    echo "<table class='widefat fixed striped'><thead><tr>
          <th>IP Address</th><th>Username</th><th>Status</th><th>Timestamp</th></tr></thead><tbody>";
    
    if (file_exists(AL_IP_LOG_FILE) && ($handle = fopen(AL_IP_LOG_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $rows = [];
        
        while (($data = fgetcsv($handle)) !== false) {
            $rows[] = $data;
        }
        fclose($handle);
        
        foreach (array_reverse(array_slice($rows, -100)) as $log) {
            if (count($log) < 4) continue;
            
            $timestamp = date('Y-m-d H:i:s', $log[3]);
            $row_class = $log[2] === 'failed' ? 'style="background-color:#ffeeee;"' : '';
            $ip_style = strpos($log[0], 'Office') !== false ? 'style="color: green; font-weight: bold;"' : '';
            
            echo "<tr $row_class><td $ip_style>{$log[0]}</td><td>{$log[1]}</td><td>{$log[2]}</td><td>{$timestamp}</td></tr>";
        }
    }
    echo "</tbody></table></div>";
}

function al_display_blocked_ips() {
    echo "<div class='wrap'><h1>Blocked IP Addresses</h1>";
    
    if (isset($_POST['unblock_ip']) && current_user_can('manage_options')) {
        check_admin_referer('al_unblock_ip', 'al_unblock_nonce');
        $ip = sanitize_text_field($_POST['unblock_ip']);
        if (al_unblock_ip($ip)) {
            echo "<div class='notice notice-success'><p>✓ IP $ip unblocked successfully.</p></div>";
        }
    }
    
    echo "<table class='widefat fixed striped'><thead><tr>
          <th>IP</th><th>Username</th><th>Attempts</th><th>Blocked Time</th><th>Reason</th><th>Action</th></tr></thead><tbody>";
    
    if (file_exists(AL_BLOCKED_IPS_FILE) && ($handle = fopen(AL_BLOCKED_IPS_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $has_data = false;
        
        while (($data = fgetcsv($handle)) !== false) {
            $has_data = true;
            echo "<tr><td>{$data[0]}</td><td>{$data[1]}</td><td>{$data[2]}</td><td>{$data[3]}</td><td>{$data[4]}</td><td>";
            echo "<form method='post' style='display:inline;'>";
            wp_nonce_field('al_unblock_ip', 'al_unblock_nonce');
            echo "<input type='hidden' name='unblock_ip' value='{$data[0]}'>";
            echo "<input type='submit' value='Unblock' class='button button-secondary'></form></td></tr>";
        }
        fclose($handle);
        
        if (!$has_data) {
            echo "<tr><td colspan='6' style='text-align:center;'>No blocked IPs.</td></tr>";
        }
    } else {
        echo "<tr><td colspan='6' style='text-align:center;'>No blocked IPs.</td></tr>";
    }
    
    echo "</tbody></table></div>";
}

function al_display_outdated_plugins() {
    echo "<div class='wrap'><h1>Outdated Plugins</h1>";
    
    $outdated = al_get_outdated_plugins();
    
    if (empty($outdated)) {
        echo "<div class='notice notice-success'><p><strong>✓ All plugins are up to date!</strong></p></div>";
    } else {
        echo "<div class='notice notice-warning'><p><strong>⚠ " . count($outdated) . " plugin(s) need updates</strong></p></div>";
        echo "<table class='widefat fixed striped'><thead><tr>
              <th>Plugin Name</th><th>Current</th><th>New Version</th><th>Action</th></tr></thead><tbody>";
        
        foreach ($outdated as $plugin_file => $plugin_data) {
            $update_url = wp_nonce_url(
                self_admin_url('update.php?action=upgrade-plugin&plugin=' . urlencode($plugin_file)),
                'upgrade-plugin_' . $plugin_file
            );
            
            echo "<tr><td><strong>{$plugin_data->Name}</strong></td>";
            echo "<td>{$plugin_data->Version}</td>";
            echo "<td><span style='color:red; font-weight:bold;'>{$plugin_data->update->new_version}</span></td>";
            echo "<td><a href='$update_url' class='button button-primary'>Update Now</a></td></tr>";
        }
        
        echo "</tbody></table>";
    }
    
    echo "</div>";
}

function al_display_security_monitor() {
    echo "<div class='wrap'><h1>🔒 Security Monitor</h1>";
    
    if (isset($_POST['run_security_scan']) && current_user_can('manage_options')) {
        check_admin_referer('al_security_scan', 'al_scan_nonce');
        al_check_security_changes();
        echo "<div class='notice notice-success'><p><strong>✓ Security scan completed!</strong></p></div>";
    }
    
    echo "<div style='margin: 20px 0; padding: 15px; background: #f0f8ff;'>";
    echo "<form method='post' style='display: inline;'>";
    wp_nonce_field('al_security_scan', 'al_scan_nonce');
    echo "<input type='submit' name='run_security_scan' value='🔍 Run Security Scan' class='button button-primary button-large'>";
    echo "</form>";
    
    $last_scan = get_option('al_last_security_scan', 0);
    if ($last_scan > 0) {
        $time_ago = human_time_diff($last_scan, current_time('timestamp')) . ' ago';
        echo "<p style='margin: 10px 0 0 0;'><strong>Last Scan:</strong> $time_ago</p>";
    }
    echo "</div>";
    
    $is_ssl = is_ssl();
    $ssl_status = $is_ssl ? '<span style="color:green; font-weight:bold;">✓ Enabled</span>' : '<span style="color:red; font-weight:bold;">✗ Disabled</span>';
    
    $firewall_active = al_get_firewall_status();
    $firewall_status = $firewall_active ? '<span style="color:green; font-weight:bold;">✓ Active</span>' : '<span style="color:red; font-weight:bold;">✗ Inactive</span>';
    
    $wp_config_path = ABSPATH . 'wp-config.php';
    $perms = file_exists($wp_config_path) ? substr(sprintf('%o', fileperms($wp_config_path)), -4) : 'N/A';
    $perms_status = $perms != 'N/A' && $perms[3] == 0 ? '<span style="color:green; font-weight:bold;">✓ Secure</span>' : '<span style="color:red; font-weight:bold;">✗ Insecure</span>';
    
    $error_reporting = ini_get('display_errors');
    $error_status = $error_reporting ? '<span style="color:red; font-weight:bold;">✗ Enabled</span>' : '<span style="color:green; font-weight:bold;">✓ Disabled</span>';
    
    $file_edit_status = defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT ? '<span style="color:green; font-weight:bold;">✓ Disabled</span>' : '<span style="color:red; font-weight:bold;">✗ Enabled</span>';
    
    $smtp_status = al_check_smtp_status();
    $smtp_display = $smtp_status['working'] ? '<span style="color:green; font-weight:bold;">✓ Working</span>' : '<span style="color:red; font-weight:bold;">✗ Not Working</span>';
    
    $outdated_count = count(al_get_outdated_plugins());
    $outdated_status = $outdated_count > 0 ? 
        "<span style='color:red; font-weight:bold;'>⚠ $outdated_count plugin(s) need update</span>" : 
        "<span style='color:green; font-weight:bold;'>✓ All up to date</span>";
    
    echo "<h2>Security Status Dashboard</h2>";
    echo "<table class='widefat fixed striped'>";
    echo "<thead><tr><th width='30%'>Security Check</th><th width='70%'>Status</th></tr></thead><tbody>";
    echo "<tr><th>SSL/HTTPS Status</th><td>$ssl_status</td></tr>";
    echo "<tr><th>Firewall Status</th><td>$firewall_status</td></tr>";
    echo "<tr><th>wp-config.php Permissions</th><td>$perms ($perms_status)</td></tr>";
    echo "<tr><th>PHP Error Display</th><td>$error_status</td></tr>";
    echo "<tr><th>File Editing in Dashboard</th><td>$file_edit_status</td></tr>";
    echo "<tr><th>SMTP Email Status</th><td>$smtp_display</td></tr>";
    echo "<tr><th>Plugin Updates</th><td>$outdated_status</td></tr>";
    echo "</tbody></table></div>";
}

function al_display_contact_form_logs() {
    echo "<div class='wrap'><h1>📧 Contact Form Submissions</h1>";
    
    echo "<table class='widefat fixed striped'><thead><tr>
          <th width='5%'>#</th><th width='8%'>Form ID</th><th width='12%'>Form Title</th>
          <th width='12%'>Name</th><th width='15%'>Email</th><th width='10%'>Phone</th>
          <th width='20%'>Message</th><th width='10%'>IP</th><th width='12%'>Timestamp</th>
          </tr></thead><tbody>";
    
    if (file_exists(AL_CONTACT_FORM_LOG_FILE) && ($handle = fopen(AL_CONTACT_FORM_LOG_FILE, 'r')) !== false) {
        $header = fgetcsv($handle);
        $rows = [];
        
        while (($data = fgetcsv($handle)) !== false) {
            $rows[] = $data;
        }
        fclose($handle);
        
        if (empty($rows)) {
            echo "<tr><td colspan='9' style='text-align:center;'>No submissions found.</td></tr>";
        } else {
            $count = count($rows);
            foreach (array_reverse($rows) as $log) {
                $message_preview = strlen($log[5]) > 50 ? substr($log[5], 0, 50) . '...' : $log[5];
                
                echo "<tr><td>{$count}</td><td>{$log[0]}</td><td>{$log[1]}</td><td>{$log[2]}</td>";
                echo "<td>{$log[3]}</td><td>{$log[4]}</td>";
                echo "<td title='" . esc_attr($log[5]) . "'>{$message_preview}</td>";
                echo "<td>{$log[6]}</td><td>{$log[7]}</td></tr>";
                $count--;
            }
        }
    } else {
        echo "<tr><td colspan='9' style='text-align:center;'>No submissions found.</td></tr>";
    }
    
    echo "</tbody></table></div>";
}

function al_display_security_settings() {
    if (isset($_POST['save_al_settings']) && current_user_can('manage_options')) {
        check_admin_referer('al_save_settings', 'al_settings_nonce');
        
        update_option('al_custom_login_slug', sanitize_text_field($_POST['custom_login_slug']));
        update_option('al_disable_file_editing', isset($_POST['disable_file_editing']));
        update_option('al_enable_file_protection', isset($_POST['enable_file_protection']));
        
        $protected_files = sanitize_textarea_field($_POST['protected_files']);
        update_option('al_protected_files', array_filter(array_map('trim', explode("\n", $protected_files))));
        
        update_option('al_enable_recaptcha', isset($_POST['enable_recaptcha']));
        update_option('al_recaptcha_site_key', sanitize_text_field($_POST['recaptcha_site_key']));
        update_option('al_recaptcha_secret_key', sanitize_text_field($_POST['recaptcha_secret_key']));
        
        echo "<div class='notice notice-success'><p><strong>✓ Settings saved!</strong></p></div>";
        al_track_activity("Security Settings Updated");
    }
    
    $custom_login = get_option('al_custom_login_slug', '');
    $disable_file_edit = get_option('al_disable_file_editing', false);
    $enable_file_protection = get_option('al_enable_file_protection', false);
    $protected_files = implode("\n", al_get_protected_files());
    $enable_recaptcha = get_option('al_enable_recaptcha', false);
    $recaptcha_site = get_option('al_recaptcha_site_key', '');
    $recaptcha_secret = get_option('al_recaptcha_secret_key', '');
    
    echo "<div class='wrap'><h1>🔒 Security Settings</h1>";
    echo "<form method='post'>";
    wp_nonce_field('al_save_settings', 'al_settings_nonce');
    
    echo "<h2>1. Custom Login URL</h2>";
    echo "<table class='form-table'><tr><th>Custom Login Slug</th><td>";
    echo "<input type='text' name='custom_login_slug' value='" . esc_attr($custom_login) . "' class='regular-text' placeholder='my-secure-login'>";
    echo "<p class='description'>Your new login URL: <strong>" . site_url('/') . "<span style='color:blue;'>" . ($custom_login ?: 'your-slug') . "</span></strong></p>";
    echo "</td></tr></table>";
    
    echo "<h2>2. Disable File Editing</h2>";
    echo "<table class='form-table'><tr><th>Disable File Editor</th><td>";
    echo "<label><input type='checkbox' name='disable_file_editing' value='1' " . checked($disable_file_edit, true, false) . "> ";
    echo "Disable theme and plugin file editor</label></td></tr></table>";
    
    echo "<h2>3. Protect Sensitive Files</h2>";
    echo "<table class='form-table'>";
    echo "<tr><th>Enable Protection</th><td>";
    echo "<label><input type='checkbox' name='enable_file_protection' value='1' " . checked($enable_file_protection, true, false) . "> ";
    echo "Block direct access to files</label></td></tr>";
    echo "<tr><th>Protected Files</th><td>";
    echo "<textarea name='protected_files' rows='5' class='large-text'>" . esc_textarea($protected_files) . "</textarea>";
    echo "<p class='description'>One per line</p></td></tr></table>";
    
    echo "<h2>4. Google reCAPTCHA</h2>";
    echo "<table class='form-table'>";
    echo "<tr><th>Enable reCAPTCHA</th><td>";
    echo "<label><input type='checkbox' name='enable_recaptcha' value='1' " . checked($enable_recaptcha, true, false) . "> ";
    echo "Add reCAPTCHA to login</label></td></tr>";
    echo "<tr><th>Site Key</th><td>";
    echo "<input type='text' name='recaptcha_site_key' value='" . esc_attr($recaptcha_site) . "' class='regular-text'>";
    echo "<p class='description'>Get keys from <a href='https://www.google.com/recaptcha/admin' target='_blank'>Google reCAPTCHA</a></p>";
    echo "</td></tr>";
    echo "<tr><th>Secret Key</th><td>";
    echo "<input type='text' name='recaptcha_secret_key' value='" . esc_attr($recaptcha_secret) . "' class='regular-text'></td></tr></table>";
    
    echo "<p class='submit'><input type='submit' name='save_al_settings' class='button button-primary button-large' value='💾 Save All Settings'></p>";
    echo "</form></div>";
}

function al_display_2fa_settings() {
    global $wpdb;
    
    echo "<div class='wrap'><h1>🔐 2FA Settings & Users</h1>";
    
    echo "<div style='background:#f0f8ff; padding:15px; margin:20px 0; border-left:4px solid #0073aa;'>";
    echo "<h3 style='margin-top:0;'>How to Enable 2FA:</h3>";
    echo "<ol>";
    echo "<li>Go to <strong>Users → Your Profile</strong></li>";
    echo "<li>Scroll down to <strong>Two-Factor Authentication</strong> section</li>";
    echo "<li>Check the <strong>Enable 2FA</strong> checkbox</li>";
    echo "<li>Click <strong>Update Profile</strong></li>";
    echo "</ol>";
    echo "<p><strong>Note:</strong> Each user must enable 2FA individually in their profile settings.</p>";
    echo "</div>";
    
    // Show users with 2FA enabled
    $users = get_users();
    echo "<h2>2FA Status by User:</h2>";
    echo "<table class='widefat striped'><thead><tr>";
    echo "<th>User</th><th>Email</th><th>2FA Status</th><th>Action</th></tr></thead><tbody>";
    
    foreach ($users as $user) {
        $enabled = get_user_meta($user->ID, 'al_enable_2fa', true) === '1';
        $status = $enabled ? '<span style="color:green; font-weight:bold;">✓ Enabled</span>' : '<span style="color:gray;">✗ Disabled</span>';
        
        echo "<tr>";
        echo "<td><strong>{$user->display_name}</strong> ({$user->user_login})</td>";
        echo "<td>{$user->user_email}</td>";
        echo "<td>{$status}</td>";
        echo "<td><a href='" . get_edit_user_link($user->ID) . "' class='button button-small'>Edit User</a></td>";
        echo "</tr>";
    }
    
    echo "</tbody></table>";
    
    echo "<div style='background:#fffbcc; padding:15px; margin:20px 0; border-left:4px solid #ffb900;'>";
    echo "<h3 style='margin-top:0;'>⚠️ Important Security Notes:</h3>";
    echo "<ul>";
    echo "<li><strong>Email Access Required:</strong> Users must have access to their registered email to receive OTP codes</li>";
    echo "<li><strong>Code Expiry:</strong> OTP codes expire after 10 minutes for security</li>";
    echo "<li><strong>Test Before Enforcing:</strong> Test 2FA on a non-admin account first</li>";
    echo "<li><strong>Backup Access:</strong> Always keep at least one admin account without 2FA as backup</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "</div>";
}

// 2FA User Profile
add_action('show_user_profile', 'al_add_2fa_profile_fields');
add_action('edit_user_profile', 'al_add_2fa_profile_fields');

function al_add_2fa_profile_fields($user) {
    $enabled = get_user_meta($user->ID, 'al_enable_2fa', true) === '1';
    ?>
    <h2>🔐 Two-Factor Authentication (2FA)</h2>
    <table class="form-table">
        <tr>
            <th><label for="al_enable_2fa">Enable 2FA</label></th>
            <td>
                <label>
                    <input type="checkbox" name="al_enable_2fa" id="al_enable_2fa" value="1" <?php checked($enabled, true); ?>>
                    Enable two-factor authentication for my account
                </label>
                <p class="description">
                    When enabled, you'll receive a 6-digit code via email (<strong><?php echo esc_html($user->user_email); ?></strong>) each time you log in.
                    <br><strong>Make sure you have access to this email!</strong>
                </p>
            </td>
        </tr>
    </table>
    <?php
}

add_action('personal_options_update', 'al_save_2fa_profile_fields');
add_action('edit_user_profile_update', 'al_save_2fa_profile_fields');

function al_save_2fa_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) return;
    
    $enable = isset($_POST['al_enable_2fa']) ? '1' : '0';
    update_user_meta($user_id, 'al_enable_2fa', $enable);
    
    $user = get_userdata($user_id);
    al_log_activity($user_id, $user->user_login, $enable === '1' ? '2FA Enabled for Account' : '2FA Disabled for Account');
}

// ============ PLUGIN ACTIVATION/DEACTIVATION ============
register_activation_hook(__FILE__, function() {
    $files_config = [
        AL_LOG_FILE => ['User ID', 'Username', 'Action', 'IP Address', 'Timestamp'],
        AL_IP_LOG_FILE => ['IP', 'Username', 'Status', 'Timestamp'],
        AL_BLOCKED_IPS_FILE => ['IP', 'Username', 'Attempts', 'Blocked Time', 'Reason'],
        AL_CONTACT_FORM_LOG_FILE => ['Form ID', 'Form Title', 'Name', 'Email', 'Phone', 'Message', 'IP Address', 'Timestamp']
    ];
    
    foreach ($files_config as $file_path => $headers) {
        if (!file_exists($file_path)) {
            $file = fopen($file_path, 'w');
            fputcsv($file, $headers);
            fclose($file);
        }
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'al_contact_form_entries';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        form_id varchar(50) NOT NULL,
        form_title varchar(255) NOT NULL,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(50) DEFAULT NULL,
        message text NOT NULL,
        ip_address varchar(100) NOT NULL,
        submitted_at datetime NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    al_check_security_changes();
    update_option('al_last_security_scan', time());
    
    if (!wp_next_scheduled('al_security_scan_hook')) {
        wp_schedule_event(time(), 'daily', 'al_security_scan_hook');
    }
    
    al_log_activity(0, 'System', 'Activity Logger Plugin Activated - 2FA System Ready');
});

register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('al_security_scan_hook');
    al_log_activity(0, 'System', 'Activity Logger Plugin Deactivated');
});

add_action('al_security_scan_hook', 'al_check_security_changes');

add_action('admin_init', function() {
    $last_scan = get_option('al_last_security_scan', 0);
    if (time() - $last_scan > AL_SECURITY_SCAN_INTERVAL) {
        al_check_security_changes();
        update_option('al_last_security_scan', time());
    }
});