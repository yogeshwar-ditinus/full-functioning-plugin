<?php
/**
 * Plugin Name: MSDP Remote Connector v5.3 - Fully Functional
 * Description: Complete implementation with proper IP blocking (4 attempts), detailed logs with reasons, SSL expiry tracking, and real-time activity monitoring
 * Version: 5.3.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) exit;

class MSDP_Remote_Connector_V53 {
    private static $instance = null;
    private $log_dir;
    
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Setup log directory
        $this->log_dir = WP_CONTENT_DIR . '/msdp-logs/';
        if (!file_exists($this->log_dir)) {
            wp_mkdir_p($this->log_dir);
        }
        
        // REST API endpoints
        add_action('rest_api_init', [$this, 'register_endpoints']);
        
        // Security enforcement
        add_action('init', [$this, 'enforce_security'], 1);
        add_action('admin_init', [$this, 'block_editor_access'], 1);
        
        // Login tracking - CRITICAL for IP blocking
        add_action('wp_login_failed', [$this, 'track_failed_login'], 10, 2);
        add_filter('authenticate', [$this, 'check_blocked_ip_before_login'], 30, 3);
        
        // Activity tracking
        $this->setup_activity_tracking();
        
        // Check and block IP on every request
        add_action('init', [$this, 'check_blocked_ip'], 0);
    }
    
    /**
     * Register REST API Endpoints
     */
    public function register_endpoints() {
        $namespace = 'msdp/v1';
        
        // Security Features
        register_rest_route($namespace, '/security/file-editor', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_file_editor'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/personal-data', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_personal_data_tools'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/hide-version', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_wp_version'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/file-protection', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_file_protection'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/login-url', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'handle_login_url'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // IP Blocking & Security Data
        register_rest_route($namespace, '/security/blocked-ips', [
            'methods' => 'GET',
            'callback' => [$this, 'get_blocked_ips'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/login-attempts', [
            'methods' => 'GET',
            'callback' => [$this, 'get_login_attempts'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/security/unblock-ip', [
            'methods' => 'POST',
            'callback' => [$this, 'unblock_ip'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // SSL Certificate Info
        register_rest_route($namespace, '/security/ssl-info', [
            'methods' => 'GET',
            'callback' => [$this, 'get_ssl_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Security Logs
        register_rest_route($namespace, '/security/logs', [
            'methods' => 'GET',
            'callback' => [$this, 'get_security_logs'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Management Features
        register_rest_route($namespace, '/manage/plugins', [
            'methods' => 'GET',
            'callback' => [$this, 'get_plugins_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/themes', [
            'methods' => 'GET',
            'callback' => [$this, 'get_themes_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/posts', [
            'methods' => 'GET',
            'callback' => [$this, 'get_posts_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/pages', [
            'methods' => 'GET',
            'callback' => [$this, 'get_pages_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/media', [
            'methods' => 'GET',
            'callback' => [$this, 'get_media_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        register_rest_route($namespace, '/manage/users', [
            'methods' => 'GET',
            'callback' => [$this, 'get_users_info'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Connection test
        register_rest_route($namespace, '/test', [
            'methods' => 'GET',
            'callback' => [$this, 'test_connection'],
            'permission_callback' => [$this, 'check_permission']
        ]);
        
        // Activity log
        register_rest_route($namespace, '/activity', [
            'methods' => 'GET',
            'callback' => [$this, 'get_activity_log'],
            'permission_callback' => [$this, 'check_permission']
        ]);
    }
    
    /**
     * Check Permission
     */
    public function check_permission($request) {
        return current_user_can('manage_options');
    }
    
    /**
     * CRITICAL: Track Failed Login Attempts
     */
    public function track_failed_login($username, $error) {
        $ip = $this->get_client_ip();
        $attempts = get_option('msdp_login_attempts', []);
        
        // Initialize or increment
        if (!isset($attempts[$ip])) {
            $attempts[$ip] = [
                'count' => 0,
                'username' => $username,
                'first_attempt' => current_time('mysql'),
                'attempts_log' => []
            ];
        }
        
        $attempts[$ip]['count']++;
        $attempts[$ip]['last_attempt'] = current_time('mysql');
        $attempts[$ip]['last_username'] = $username;
        $attempts[$ip]['attempts_log'][] = [
            'time' => current_time('mysql'),
            'username' => $username,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
        ];
        
        // Log to file
        $this->write_log('security', 'failed_login', [
            'ip' => $ip,
            'username' => $username,
            'attempt_number' => $attempts[$ip]['count'],
            'reason' => 'Invalid username or password',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'severity' => 'warning'
        ]);
        
        // Block after 4 attempts
        if ($attempts[$ip]['count'] >= 4) {
            $blocked_ips = get_option('msdp_blocked_ips', []);
            
            if (!isset($blocked_ips[$ip])) {
                $blocked_ips[$ip] = [
                    'ip' => $ip,
                    'reason' => "Blocked after {$attempts[$ip]['count']} failed login attempts",
                    'username_tried' => $username,
                    'blocked_at' => current_time('mysql'),
                    'attempts' => $attempts[$ip]['count'],
                    'status' => 'blocked'
                ];
                
                update_option('msdp_blocked_ips', $blocked_ips);
                
                // Log IP blocking
                $this->write_log('security', 'ip_blocked', [
                    'ip' => $ip,
                    'reason' => "Auto-blocked after {$attempts[$ip]['count']} failed login attempts",
                    'username' => $username,
                    'severity' => 'critical'
                ]);
                
                // Clear attempts for this IP
                unset($attempts[$ip]);
            }
        }
        
        update_option('msdp_login_attempts', $attempts);
    }
    
    /**
     * Check if IP is Blocked Before Login
     */
    public function check_blocked_ip_before_login($user, $username, $password) {
        $ip = $this->get_client_ip();
        $blocked_ips = get_option('msdp_blocked_ips', []);
        
        if (isset($blocked_ips[$ip])) {
            $this->write_log('security', 'blocked_ip_access_attempt', [
                'ip' => $ip,
                'username' => $username,
                'reason' => 'Attempted login from blocked IP',
                'severity' => 'critical'
            ]);
            
            return new WP_Error(
                'ip_blocked',
                '<strong>ERROR:</strong> Your IP address has been blocked due to multiple failed login attempts. Please contact the administrator.'
            );
        }
        
        return $user;
    }
    
    /**
     * Check Blocked IP on Every Request
     */
    public function check_blocked_ip() {
        // Skip for REST API authentication requests
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return;
        }
        
        $ip = $this->get_client_ip();
        $blocked_ips = get_option('msdp_blocked_ips', []);
        
        if (isset($blocked_ips[$ip]) && !current_user_can('manage_options')) {
            $this->write_log('security', 'blocked_ip_access', [
                'ip' => $ip,
                'url' => $_SERVER['REQUEST_URI'] ?? '/',
                'reason' => 'Blocked IP attempted to access site',
                'severity' => 'warning'
            ]);
            
            wp_die(
                '<h1>Access Denied</h1><p>Your IP address has been blocked.</p><p>Blocked IP: <strong>' . esc_html($ip) . '</strong></p>',
                'Access Denied',
                ['response' => 403]
            );
        }
    }
    
    /**
     * Get Blocked IPs
     */
    public function get_blocked_ips() {
        $blocked_ips = get_option('msdp_blocked_ips', []);
        return rest_ensure_response([
            'success' => true,
            'blocked_ips' => array_values($blocked_ips),
            'total' => count($blocked_ips)
        ]);
    }
    
    /**
     * Get Login Attempts
     */
    public function get_login_attempts() {
        $attempts = get_option('msdp_login_attempts', []);
        return rest_ensure_response([
            'success' => true,
            'attempts' => array_values($attempts),
            'total' => count($attempts)
        ]);
    }
    
    /**
     * Unblock IP Address
     */
    public function unblock_ip($request) {
        $ip = sanitize_text_field($request->get_param('ip'));
        
        if (empty($ip)) {
            return rest_ensure_response([
                'success' => false,
                'message' => 'IP address is required'
            ]);
        }
        
        $blocked_ips = get_option('msdp_blocked_ips', []);
        
        if (isset($blocked_ips[$ip])) {
            unset($blocked_ips[$ip]);
            update_option('msdp_blocked_ips', $blocked_ips);
            
            // Log unblocking
            $this->write_log('security', 'ip_unblocked', [
                'ip' => $ip,
                'reason' => 'Manually unblocked by administrator',
                'unblocked_by' => wp_get_current_user()->user_login,
                'severity' => 'info'
            ]);
            
            return rest_ensure_response([
                'success' => true,
                'message' => 'IP unblocked successfully'
            ]);
        }
        
        return rest_ensure_response([
            'success' => false,
            'message' => 'IP not found in blocked list'
        ]);
    }
    
    /**
     * Get SSL Certificate Information
     */
    public function get_ssl_info() {
        $url = home_url();
        $parsed = parse_url($url);
        $host = $parsed['host'];
        
        if ($parsed['scheme'] !== 'https') {
            return rest_ensure_response([
                'success' => false,
                'ssl_enabled' => false,
                'message' => 'Site is not using HTTPS'
            ]);
        }
        
        $stream = @stream_context_create(['ssl' => ['capture_peer_cert' => true]]);
        $socket = @stream_socket_client(
            "ssl://{$host}:443",
            $errno,
            $errstr,
            30,
            STREAM_CLIENT_CONNECT,
            $stream
        );
        
        if (!$socket) {
            return rest_ensure_response([
                'success' => false,
                'ssl_enabled' => true,
                'message' => 'Could not connect to get SSL info'
            ]);
        }
        
        $params = stream_context_get_params($socket);
        $cert = openssl_x509_parse($params['options']['ssl']['peer_certificate']);
        
        fclose($socket);
        
        $valid_from = date('Y-m-d H:i:s', $cert['validFrom_time_t']);
        $valid_to = date('Y-m-d H:i:s', $cert['validTo_time_t']);
        $days_left = floor(($cert['validTo_time_t'] - time()) / 86400);
        
        return rest_ensure_response([
            'success' => true,
            'ssl_enabled' => true,
            'issuer' => $cert['issuer']['CN'] ?? 'Unknown',
            'valid_from' => $valid_from,
            'valid_to' => $valid_to,
            'expires_in_days' => $days_left,
            'expires_on' => $valid_to,
            'status' => $days_left > 30 ? 'valid' : ($days_left > 0 ? 'expiring_soon' : 'expired'),
            'subject' => $cert['subject']['CN'] ?? $host
        ]);
    }
    
    /**
     * Get Security Logs
     */
    public function get_security_logs() {
        $logs = [];
        $log_files = glob($this->log_dir . '*.log');
        
        // Get last 50 log entries
        foreach (array_slice($log_files, -10) as $file) {
            $content = file_get_contents($file);
            $lines = explode("\n", $content);
            
            foreach (array_slice($lines, -5) as $line) {
                if (!empty(trim($line))) {
                    $logs[] = $line;
                }
            }
        }
        
        return rest_ensure_response([
            'success' => true,
            'logs' => array_slice(array_reverse($logs), 0, 50),
            'total' => count($logs)
        ]);
    }
    
    /**
     * Write Log to File with Detailed Information
     */
    private function write_log($type, $action, $data = []) {
        $date = current_time('Y-m-d');
        $filename = $this->log_dir . $date . '_' . $type . '.log';
        
        $log_entry = [
            'timestamp' => current_time('mysql'),
            'type' => $type,
            'action' => $action,
            'ip' => $this->get_client_ip(),
            'user' => wp_get_current_user()->user_login ?? 'guest',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'data' => $data
        ];
        
        $log_line = sprintf(
            "[%s] [%s] [%s] IP:%s User:%s Action:%s | %s\n",
            $log_entry['timestamp'],
            strtoupper($data['severity'] ?? 'info'),
            strtoupper($type),
            $log_entry['ip'],
            $log_entry['user'],
            $action,
            json_encode($data)
        );
        
        file_put_contents($filename, $log_line, FILE_APPEND);
        
        // Also save to database option for quick access
        $db_logs = get_option('msdp_recent_logs', []);
        $db_logs[] = $log_entry;
        $db_logs = array_slice($db_logs, -100); // Keep last 100
        update_option('msdp_recent_logs', $db_logs);
    }
    
    /**
     * Get Client IP Address
     */
    private function get_client_ip() {
        $ip_keys = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && !empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                // Handle comma-separated IPs (X-Forwarded-For)
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Enforce Security Settings
     */
    public function enforce_security() {
        // File Editor
        if (get_option('msdp_file_editor_disabled', 0)) {
            if (!defined('DISALLOW_FILE_EDIT')) {
                define('DISALLOW_FILE_EDIT', true);
            }
            add_filter('user_has_cap', [$this, 'remove_editor_capability'], 10, 4);
        }
        
        // Personal Data Tools
        if (get_option('msdp_personal_data_tools_disabled', 0)) {
            add_filter('user_has_cap', [$this, 'remove_privacy_capability'], 10, 4);
        }
        
        // Hide WordPress version
        if (get_option('msdp_hide_wp_version', 0)) {
            remove_action('wp_head', 'wp_generator');
            add_filter('the_generator', '__return_empty_string');
        }
    }
    
    /**
     * Remove Editor Capability
     */
    public function remove_editor_capability($allcaps, $caps, $args, $user) {
        if (isset($allcaps['edit_themes'])) $allcaps['edit_themes'] = false;
        if (isset($allcaps['edit_plugins'])) $allcaps['edit_plugins'] = false;
        return $allcaps;
    }
    
    /**
     * Remove Privacy Capability
     */
    public function remove_privacy_capability($allcaps, $caps, $args, $user) {
        if (isset($allcaps['export_others_personal_data'])) $allcaps['export_others_personal_data'] = false;
        if (isset($allcaps['erase_others_personal_data'])) $allcaps['erase_others_personal_data'] = false;
        if (isset($allcaps['manage_privacy_options'])) $allcaps['manage_privacy_options'] = false;
        return $allcaps;
    }
    
    /**
     * Block Editor Access
     */
    public function block_editor_access() {
        global $pagenow;
        
        if (get_option('msdp_file_editor_disabled', 0)) {
            if ($pagenow === 'theme-editor.php' || $pagenow === 'plugin-editor.php') {
                wp_die(
                    '<h1>Editor Disabled</h1><p>The file editor has been disabled by your administrator.</p>',
                    'Editor Disabled',
                    ['response' => 403, 'back_link' => true]
                );
            }
            remove_submenu_page('themes.php', 'theme-editor.php');
            remove_submenu_page('plugins.php', 'plugin-editor.php');
        }
        
        if (get_option('msdp_personal_data_tools_disabled', 0)) {
            if ($pagenow === 'export-personal-data.php' || $pagenow === 'erase-personal-data.php') {
                wp_die(
                    '<h1>Access Denied</h1><p>Personal data tools have been disabled.</p>',
                    'Access Denied',
                    ['response' => 403, 'back_link' => true]
                );
            }
            remove_submenu_page('tools.php', 'export-personal-data.php');
            remove_submenu_page('tools.php', 'erase-personal-data.php');
        }
    }
    
    /**
     * Security Feature Handlers (File Editor, Personal Data, etc.)
     */
    public function handle_file_editor($request) {
        if ($request->get_method() === 'POST') {
            $enable = $request->get_param('enabled');
            
            if (!$enable) {
                $this->add_constant_to_config('DISALLOW_FILE_EDIT', 'true');
                update_option('msdp_file_editor_disabled', 1);
                $this->write_log('security', 'file_editor_disabled', ['reason' => 'Administrator disabled file editor', 'severity' => 'info']);
            } else {
                $this->remove_constant_from_config('DISALLOW_FILE_EDIT');
                update_option('msdp_file_editor_disabled', 0);
                $this->write_log('security', 'file_editor_enabled', ['reason' => 'Administrator enabled file editor', 'severity' => 'info']);
            }
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => $enable,
                'message' => $enable ? 'File editor enabled' : 'File editor disabled'
            ]);
        }
        
        $disabled = get_option('msdp_file_editor_disabled', 0);
        return rest_ensure_response([
            'enabled' => !$disabled,
            'status' => $disabled ? 'disabled' : 'enabled'
        ]);
    }
    
    public function handle_personal_data_tools($request) {
        if ($request->get_method() === 'POST') {
            $enable = $request->get_param('enabled');
            
            update_option('msdp_personal_data_tools_disabled', $enable ? 0 : 1);
            $this->write_log('security', 'personal_data_tools_' . ($enable ? 'enabled' : 'disabled'), [
                'reason' => 'Administrator changed personal data tools setting',
                'severity' => 'info'
            ]);
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => $enable,
                'message' => $enable ? 'Personal data tools enabled' : 'Personal data tools disabled'
            ]);
        }
        
        $disabled = get_option('msdp_personal_data_tools_disabled', 0);
        return rest_ensure_response([
            'enabled' => !$disabled,
            'status' => $disabled ? 'disabled' : 'enabled'
        ]);
    }
    
    public function handle_wp_version($request) {
        if ($request->get_method() === 'POST') {
            $hide = !$request->get_param('enabled');
            update_option('msdp_hide_wp_version', $hide ? 1 : 0);
            $this->write_log('security', 'wp_version_' . ($hide ? 'hidden' : 'visible'), ['severity' => 'info']);
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => !$hide,
                'message' => $hide ? 'WordPress version hidden' : 'WordPress version visible'
            ]);
        }
        
        $hidden = get_option('msdp_hide_wp_version', 0);
        return rest_ensure_response(['enabled' => !$hidden, 'status' => $hidden ? 'hidden' : 'visible']);
    }
    
    public function handle_file_protection($request) {
        if ($request->get_method() === 'POST') {
            $enable = $request->get_param('enabled');
            
            if ($enable) {
                $this->create_htaccess_protection();
                update_option('msdp_file_protection_enabled', 1);
                $this->write_log('security', 'file_protection_enabled', ['severity' => 'info']);
            } else {
                $this->remove_htaccess_protection();
                update_option('msdp_file_protection_enabled', 0);
                $this->write_log('security', 'file_protection_disabled', ['severity' => 'info']);
            }
            
            return rest_ensure_response([
                'success' => true,
                'enabled' => $enable,
                'message' => $enable ? 'File protection enabled' : 'File protection disabled'
            ]);
        }
        
        $enabled = get_option('msdp_file_protection_enabled', 0);
        return rest_ensure_response(['enabled' => (bool)$enabled, 'status' => $enabled ? 'enabled' : 'disabled']);
    }
    
    public function handle_login_url($request) {
        if ($request->get_method() === 'POST') {
            $slug = sanitize_title($request->get_param('slug'));
            
            if (empty($slug)) {
                return rest_ensure_response(['success' => false, 'message' => 'Login slug cannot be empty']);
            }
            
            update_option('msdp_custom_login_slug', $slug);
            $this->write_log('security', 'login_url_changed', ['slug' => $slug, 'severity' => 'info']);
            
            return rest_ensure_response([
                'success' => true,
                'slug' => $slug,
                'message' => 'Login URL changed successfully',
                'new_url' => home_url($slug)
            ]);
        }
        
        $slug = get_option('msdp_custom_login_slug', '');
        return rest_ensure_response([
            'slug' => $slug,
            'current_url' => $slug ? home_url($slug) : wp_login_url()
        ]);
    }
    
    /**
     * Management Info Methods
     */
    public function get_plugins_info() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins', []);
        
        return rest_ensure_response([
            'success' => true,
            'total' => count($all_plugins),
            'active' => count($active_plugins),
            'inactive' => count($all_plugins) - count($active_plugins),
            'admin_url' => admin_url('plugins.php')
        ]);
    }
    
    public function get_themes_info() {
        $all_themes = wp_get_themes();
        $current_theme = wp_get_theme();
        
        return rest_ensure_response([
            'success' => true,
            'total' => count($all_themes),
            'current' => $current_theme->get('Name'),
            'admin_url' => admin_url('themes.php')
        ]);
    }
    
    public function get_posts_info() {
        $posts = wp_count_posts('post');
        
        return rest_ensure_response([
            'success' => true,
            'total' => $posts->publish + $posts->draft,
            'published' => $posts->publish,
            'draft' => $posts->draft,
            'admin_url' => admin_url('edit.php')
        ]);
    }
    
    public function get_pages_info() {
        $pages = wp_count_posts('page');
        
        return rest_ensure_response([
            'success' => true,
            'total' => $pages->publish + $pages->draft,
            'published' => $pages->publish,
            'draft' => $pages->draft,
            'admin_url' => admin_url('edit.php?post_type=page')
        ]);
    }
    
    public function get_media_info() {
        $media = wp_count_posts('attachment');
        
        return rest_ensure_response([
            'success' => true,
            'total' => $media->inherit,
            'admin_url' => admin_url('upload.php')
        ]);
    }
    
    public function get_users_info() {
        $users = count_users();
        
        return rest_ensure_response([
            'success' => true,
            'total' => $users['total_users'],
            'admin_url' => admin_url('users.php')
        ]);
    }
    
    public function test_connection() {
        return rest_ensure_response([
            'success' => true,
            'message' => 'Connection successful',
            'site_url' => get_site_url(),
            'wp_version' => get_bloginfo('version'),
            'timestamp' => current_time('mysql')
        ]);
    }
    
    public function get_activity_log() {
        $logs = get_option('msdp_recent_logs', []);
        return rest_ensure_response([
            'success' => true,
            'logs' => array_slice($logs, -50)
        ]);
    }
    
    /**
     * Activity Tracking
     */
    private function setup_activity_tracking() {
        // User actions
        add_action('user_register', function($user_id) {
            $user = get_userdata($user_id);
            $this->write_log('activity', 'user_created', [
                'user_login' => $user->user_login,
                'user_id' => $user_id,
                'reason' => 'New user registered',
                'severity' => 'info'
            ]);
        });
        
        add_action('delete_user', function($user_id) {
            $user = get_userdata($user_id);
            $this->write_log('activity', 'user_deleted', [
                'user_login' => $user->user_login,
                'user_id' => $user_id,
                'reason' => 'User account deleted',
                'severity' => 'warning'
            ]);
        });
        
        // Plugin actions
        add_action('activated_plugin', function($plugin) {
            $this->write_log('activity', 'plugin_activated', [
                'plugin' => $plugin,
                'reason' => 'Plugin activated by administrator',
                'severity' => 'info'
            ]);
        });
        
        add_action('deactivated_plugin', function($plugin) {
            $this->write_log('activity', 'plugin_deactivated', [
                'plugin' => $plugin,
                'reason' => 'Plugin deactivated by administrator',
                'severity' => 'info'
            ]);
        });
        
        // Theme changes
        add_action('switch_theme', function($new_name, $new_theme) {
            $this->write_log('activity', 'theme_switched', [
                'theme' => $new_name,
                'reason' => 'Theme changed by administrator',
                'severity' => 'info'
            ]);
        }, 10, 2);
        
        // Post/Page publishing
        add_action('publish_post', function($post_id) {
            $post = get_post($post_id);
            $this->write_log('activity', 'post_published', [
                'post_id' => $post_id,
                'post_title' => $post->post_title,
                'reason' => 'New post published',
                'severity' => 'info'
            ]);
        });
    }
    
    /**
     * Helper Methods
     */
    private function add_constant_to_config($constant, $value) {
        $config_file = ABSPATH . 'wp-config.php';
        if (!file_exists($config_file) || !is_writable($config_file)) return false;
        
        $config = file_get_contents($config_file);
        $config = preg_replace("/define\s*\(\s*['\"]" . $constant . "['\"]\s*,\s*.*?\s*\)\s*;/", '', $config);
        
        $new_constant = "define('" . $constant . "', " . $value . ");\n";
        $config = str_replace("/* That's all, stop editing!", $new_constant . "/* That's all, stop editing!", $config);
        
        return file_put_contents($config_file, $config);
    }
    
    private function remove_constant_from_config($constant) {
        $config_file = ABSPATH . 'wp-config.php';
        if (!file_exists($config_file) || !is_writable($config_file)) return false;
        
        $config = file_get_contents($config_file);
        $config = preg_replace("/define\s*\(\s*['\"]" . $constant . "['\"]\s*,\s*.*?\s*\)\s*;\n?/", '', $config);
        
        return file_put_contents($config_file, $config);
    }
    
    private function create_htaccess_protection() {
        $htaccess_file = ABSPATH . '.htaccess';
        if (!file_exists($htaccess_file)) return false;
        
        $protection_rules = "\n# MSDP Security Protection - START\n";
        $protection_rules .= "<Files wp-config.php>\nOrder deny,allow\nDeny from all\n</Files>\n";
        $protection_rules .= "<Files readme.html>\nOrder deny,allow\nDeny from all\n</Files>\n";
        $protection_rules .= "<Files license.txt>\nOrder deny,allow\nDeny from all\n</Files>\n";
        $protection_rules .= "<Files xmlrpc.php>\nOrder deny,allow\nDeny from all\n</Files>\n";
        $protection_rules .= "# MSDP Security Protection - END\n";
        
        $current_htaccess = file_get_contents($htaccess_file);
        $current_htaccess = preg_replace('/# MSDP Security Protection - START.*?# MSDP Security Protection - END\n/s', '', $current_htaccess);
        
        $new_htaccess = $protection_rules . $current_htaccess;
        return file_put_contents($htaccess_file, $new_htaccess);
    }
    
    private function remove_htaccess_protection() {
        $htaccess_file = ABSPATH . '.htaccess';
        if (!file_exists($htaccess_file)) return false;
        
        $current_htaccess = file_get_contents($htaccess_file);
        $new_htaccess = preg_replace('/# MSDP Security Protection - START.*?# MSDP Security Protection - END\n/s', '', $current_htaccess);
        
        return file_put_contents($htaccess_file, $new_htaccess);
    }
}

// Initialize
MSDP_Remote_Connector_V53::instance();
